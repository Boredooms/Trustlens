"use strict";
(() => {
  // src/shared/config.ts
  var API_BASE_URL = "http://localhost:8000".replace(/\/+$/, "");
  var WEB_BASE_URL = "http://localhost:5173".replace(/\/+$/, "");
  var EXT_VERSION = "0.5.0";
  var CONNECT_URL = `${WEB_BASE_URL}/app/developers?connect=extension`;

  // src/shared/messages.ts
  async function send(msg) {
    try {
      const reply = await chrome.runtime.sendMessage(msg);
      if (!reply || typeof reply !== "object" || !("ok" in reply)) {
        return { ok: false, error: { code: "NO_REPLY", message: "The extension did not respond." } };
      }
      return reply;
    } catch (err) {
      return { ok: false, error: { code: "TRANSPORT", message: err instanceof Error ? err.message : String(err) } };
    }
  }

  // src/content/bridge.ts
  var FROM_WEB = "trustlens-web";
  var FROM_EXT = "trustlens-extension";
  var MARK = "__trustlensBridgeLoaded";
  function post(payload) {
    window.postMessage({ source: FROM_EXT, ...payload }, location.origin);
  }
  async function announce() {
    const hello = await send({ type: "BRIDGE_HELLO" });
    post({ type: "TRUSTLENS_EXTENSION", version: EXT_VERSION, paired: hello.ok ? hello.data.paired : false });
  }
  function init() {
    document.documentElement.dataset.trustlensExtension = EXT_VERSION;
    window.addEventListener("message", (e) => {
      if (e.source !== window || e.origin !== location.origin) return;
      const d = e.data;
      if (!d || d.source !== FROM_WEB || typeof d.type !== "string") return;
      if (d.type === "PING") {
        void announce();
        return;
      }
      if (d.type === "PAIR" && typeof d.code === "string") {
        const requestId = typeof d.requestId === "string" ? d.requestId.slice(0, 64) : null;
        const deviceName = typeof d.deviceName === "string" ? d.deviceName.slice(0, 100) : "Chrome";
        void (async () => {
          const reply = await send({ type: "PAIR_FROM_DASHBOARD", code: d.code, deviceName });
          post(
            reply.ok ? { type: "PAIR_RESULT", requestId, ok: true, paired: reply.data.paired } : { type: "PAIR_RESULT", requestId, ok: false, code: reply.error.code }
          );
        })();
      }
    });
    void announce();
    void send({ type: "PAGE_READY", url: location.href });
  }
  var g = globalThis;
  if (!g[MARK]) {
    g[MARK] = true;
    init();
  }
})();
