"use strict";
(() => {
  // src/shared/copy.ts
  var COPY = {
    product: "TrustLens",
    allowSublabel: "Based on {n}% coverage. This is not a guarantee.",
    allowToast: "No known threat in the checks that ran · coverage {n}%",
    allowToastNoCoverage: "No known threat in the checks that ran · coverage not reported",
    coverageLine: "We checked {n}% of signal groups.",
    coverageMissing: "Coverage was not reported for this check.",
    decidedAgo: "Decided {ago}.",
    checking: { payment: "Checking this payment…", login: "Checking this login…" },
    stopped: { payment: "Payment stopped", login: "Login stopped" },
    suspicious: { payment: "Check this payment first", login: "Check this login first" },
    review: { payment: "This payment needs review", login: "This login needs review" },
    couldNotVerify: "Could not verify this page",
    couldNotVerifyBody: {
      payment: "TrustLens could not check this payment. It was not checked — decide for yourself.",
      login: "TrustLens could not check this login. It was not checked — decide for yourself."
    },
    payeeMismatch: "This page asks you to pay {observed}. {org} has registered {expected}.",
    payeeObservedOnly: "This page asks you to pay {observed}.",
    credentialMismatch: "This login form sends your password to {observed}, which is not an approved {org} login endpoint.",
    unknownOrg: "The organisation this page claims to be",
    goBack: "Go back",
    proceedAnyway: "Proceed anyway",
    proceedConfirm: "I understand the risk — proceed",
    continue: "Continue",
    continueAnyway: "Continue without a check",
    details: "Details",
    dismiss: "Dismiss",
    fullReport: "Full report",
    reportPage: "Report this page",
    appealSite: "Is this your site? Appeal this decision",
    reportSite: "Report this site",
    reportSent: "Report sent. You'll see updates in the dashboard.",
    reportQueued: "Could not send the report right now.",
    reportJustificationHint: "Optional: what happened? (10–500 characters)",
    overrideCounted: "Proceeding. This override is counted locally.",
    reasonsHeading: "Why",
    warnNoReason: "open TrustLens for details",
    pausedBanner: "Protection paused",
    pair: {
      heading: "Connect TrustLens",
      body: "Connect once and every page you open is checked in real time.",
      oneClick: "Connect in one click",
      oneClickHint: "Opens your TrustLens dashboard and connects this browser. Sign in first if asked.",
      manualToggle: "Have a code? Enter it instead",
      manualBody: "In the dashboard open Developers → Browser extension, choose “Generate pairing code”, and enter the 8-character code here.",
      codeLabel: "Pairing code",
      submit: "Connect",
      working: "Working…",
      connected: "Connected",
      reconnect: "Reconnect TrustLens to keep protecting you.",
      invalidCode: "That code is not valid or has expired. Get a new one from the dashboard.",
      failed: "Could not connect right now. Try again in a moment."
    },
    popup: {
      currentPage: "This page",
      noPage: "Browser pages (new tab, settings, the web store) cannot be checked.",
      watchPage: "Watch this tab for logins and payments",
      watching: "Watching this tab.",
      options: "Settings",
      version: "Version {v}",
      checkingLive: "Checking {host} live…",
      checkingHint: "First visits run a full server-side scan; repeat visits are instant.",
      recheck: "Re-check",
      explainAi: "Explain with AI",
      explainHint: "Opens the report and starts an AI investigation that cites the evidence. The AI never changes the decision.",
      protectionOn: "Real-time protection on",
      protectionOff: "Protection paused",
      connected: "Connected",
      notConnected: "Not connected",
      apiDown: "TrustLens server unreachable",
      scoreLabel: "Risk score",
      findings: "What the checks found",
      noFindings: "No finding from the checks that ran.",
      fromCache: "Saved result · {ago}"
    },
    options: {
      apiStatus: "API status",
      apiUp: "Reachable",
      apiDown: "Unreachable — pages will show “not checked”.",
      pairing: "Pairing",
      unpair: "Disconnect this browser",
      unpaired: "Disconnected. Pages will show “not checked” until you reconnect.",
      clearData: "Clear all local data",
      cleared: "Local data cleared.",
      privacyHeading: "What TrustLens sends",
      privacy: [
        "Sent on a check: the page address, the form's destination address, whether a password field exists, and the payee text the page itself displays.",
        "Never read or sent: anything you type (passwords, one-time codes, card numbers), cookies, page HTML, screenshots, or your browsing history.",
        "The server makes every decision. If it cannot be reached, TrustLens says the page was not checked."
      ]
    }
  };
  function fill(template, values) {
    return template.replace(/\{(\w+)\}/g, (m, k) => k in values ? String(values[k]) : m);
  }

  // src/shared/config.ts
  var API_BASE_URL = "http://localhost:8000".replace(/\/+$/, "");
  var WEB_BASE_URL = "http://localhost:5173".replace(/\/+$/, "");
  var EXT_VERSION = "0.4.1";
  var CONNECT_URL = `${WEB_BASE_URL}/app/developers?connect=extension`;

  // src/shared/messages.ts
  async function send(msg) {
    try {
      const reply = await chrome.runtime.sendMessage(msg);
      if (!reply || typeof reply !== "object" || !("ok" in reply)) {
        return { ok: false, error: { code: "NO_REPLY", message: "The extension did not respond." } };
      }
      return reply;
    } catch (err) {
      return { ok: false, error: { code: "TRANSPORT", message: err instanceof Error ? err.message : String(err) } };
    }
  }

  // src/shared/page.ts
  function h(tag, props = {}, children = []) {
    const e = document.createElement(tag);
    if (props.className) e.className = props.className;
    if (props.text !== void 0) e.textContent = props.text;
    for (const [k, v] of Object.entries(props.attrs ?? {})) e.setAttribute(k, v);
    for (const c of children) if (c) e.appendChild(c);
    return e;
  }
  function byId(id) {
    const e = document.getElementById(id);
    if (!e) throw new Error(`missing #${id}`);
    return e;
  }

  // src/shared/pair-form.ts
  function deviceName() {
    const ua = navigator.userAgent;
    const os = /Windows/.test(ua) ? "Windows" : /Mac OS X/.test(ua) ? "macOS" : /Linux/.test(ua) ? "Linux" : "desktop";
    return `Chrome on ${os}`;
  }
  function wirePairForm(form, input, errorEl, onPaired) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const button = form.querySelector("button[type=submit]");
      errorEl.textContent = "";
      if (button) {
        button.disabled = true;
        button.textContent = COPY.pair.working;
      }
      const code = input.value;
      const reply = await send({ type: "PAIR", code, deviceName: deviceName() });
      if (button) {
        button.disabled = false;
        button.textContent = COPY.pair.submit;
      }
      if (reply.ok) {
        input.value = "";
        onPaired(reply.data);
        return;
      }
      errorEl.textContent = reply.error.code === "INVALID_CODE" ? COPY.pair.invalidCode : COPY.pair.failed;
    });
  }

  // src/options/options.ts
  byId("version").textContent = fill(COPY.popup.version, { v: EXT_VERSION });
  byId("api-origin").textContent = API_BASE_URL;
  byId("privacy").replaceChildren(...COPY.options.privacy.map((p) => h("li", { text: p })));
  async function checkApi() {
    const el = byId("api-status");
    el.textContent = "Checking…";
    const r = await send({ type: "API_STATUS" });
    el.textContent = r.ok && r.data.reachable ? `${COPY.options.apiUp}${r.data.version ? ` · API ${r.data.version}` : ""}` : COPY.options.apiDown;
  }
  function renderPairing(s) {
    const state = byId("pair-state");
    if (s.paired) {
      state.textContent = `${COPY.pair.connected}${s.deviceId ? ` · device ${s.deviceId}` : ""}${s.expiresAt ? ` · expires ${s.expiresAt}` : ""}`;
    } else {
      state.textContent = s.needsReconnect ? COPY.pair.reconnect : COPY.pair.body;
    }
    byId("pair-form").hidden = s.paired;
    byId("unpair").hidden = !s.paired;
  }
  wirePairForm(byId("pair-form"), byId("pair-code"), byId("pair-error"), renderPairing);
  byId("unpair").addEventListener("click", async () => {
    const r = await send({ type: "UNPAIR" });
    if (r.ok) {
      renderPairing(r.data);
      byId("pair-state").textContent = COPY.options.unpaired;
    }
  });
  byId("clear").addEventListener("click", async () => {
    const r = await send({ type: "CLEAR_DATA" });
    byId("clear-status").textContent = r.ok ? COPY.options.cleared : COPY.pair.failed;
    const p = await send({ type: "GET_PAIRING" });
    if (p.ok) renderPairing(p.data);
  });
  var enabled = byId("enabled");
  enabled.addEventListener("change", () => void send({ type: "SET_SETTINGS", patch: { enabled: enabled.checked } }));
  byId("api-recheck").addEventListener("click", () => void checkApi());
  void (async () => {
    const [p, s] = await Promise.all([send({ type: "GET_PAIRING" }), send({ type: "GET_SETTINGS" })]);
    if (p.ok) renderPairing(p.data);
    if (s.ok) enabled.checked = s.data.enabled;
    await checkApi();
  })();
})();
