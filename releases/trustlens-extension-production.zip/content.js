"use strict";
(() => {
  // src/shared/config.ts
  var API_BASE_URL = "https://trustlens-api-m65a.onrender.com".replace(/\/+$/, "");
  var WEB_BASE_URL = "https://trustlens-web-three.vercel.app".replace(/\/+$/, "");
  var DEMO_SITES_ORIGIN = "https://trustlens-demo-northstar.vercel.app";
  function fullReportUrl(scanId) {
    return `${WEB_BASE_URL}/app/scan/${encodeURIComponent(scanId)}`;
  }
  var CONNECT_URL = `${WEB_BASE_URL}/app/developers?connect=extension`;
  function appealUrl(host2) {
    return `${WEB_BASE_URL}/appeal?domain=${encodeURIComponent(host2)}`;
  }
  function isAppealable(decision) {
    return decision === "BLOCK" || decision === "WARN";
  }

  // src/shared/copy.ts
  var DECISION_COPY = {
    BLOCK: {
      label: "Blocked",
      headline: "Blocked: {reason}",
      srText: "TrustLens decision: blocked.",
      icon: "shield-x",
      badge: "!"
    },
    WARN: {
      label: "Suspicious",
      headline: "Suspicious: {reason}",
      srText: "TrustLens decision: suspicious.",
      icon: "shield-alert",
      badge: "!"
    },
    ALLOW: {
      label: "No known threat",
      headline: "No known threat ({coverage}% checked)",
      srText: "TrustLens decision: no known threat in the checks that ran. This is not a guarantee.",
      icon: "shield-check",
      badge: ""
    },
    REVIEW: {
      label: "Needs review",
      headline: "Needs review: not enough evidence",
      srText: "TrustLens decision: needs review. Signals conflict or coverage is too low.",
      icon: "search",
      badge: "?"
    },
    UNKNOWN: {
      label: "Not verified",
      headline: "Not verified: {reason}",
      srText: "TrustLens could not verify this page. It was not checked.",
      icon: "shield-question",
      badge: "?"
    }
  };
  var COPY = {
    product: "TrustLens",
    allowSublabel: "Based on {n}% coverage. This is not a guarantee.",
    allowToast: "No known threat in the checks that ran · coverage {n}%",
    allowToastNoCoverage: "No known threat in the checks that ran · coverage not reported",
    coverageLine: "We checked {n}% of signal groups.",
    coverageMissing: "Coverage was not reported for this check.",
    decidedAgo: "Decided {ago}.",
    checking: { payment: "Checking this payment…", login: "Checking this login…" },
    stopped: { payment: "Payment stopped", login: "Login stopped" },
    suspicious: { payment: "Check this payment first", login: "Check this login first" },
    review: { payment: "This payment needs review", login: "This login needs review" },
    couldNotVerify: "Could not verify this page",
    couldNotVerifyBody: {
      payment: "TrustLens could not check this payment. It was not checked — decide for yourself.",
      login: "TrustLens could not check this login. It was not checked — decide for yourself."
    },
    payeeMismatch: "This page asks you to pay {observed}. {org} has registered {expected}.",
    payeeObservedOnly: "This page asks you to pay {observed}.",
    credentialMismatch: "This login form sends your password to {observed}, which is not an approved {org} login endpoint.",
    unknownOrg: "The organisation this page claims to be",
    goBack: "Go back",
    proceedAnyway: "Proceed anyway",
    proceedConfirm: "I understand the risk — proceed",
    continue: "Continue",
    continueAnyway: "Continue without a check",
    details: "Details",
    dismiss: "Dismiss",
    fullReport: "Full report",
    reportPage: "Report this page",
    appealSite: "Is this your site? Appeal this decision",
    reportSite: "Report this site",
    reportSent: "Report sent. You'll see updates in the dashboard.",
    reportQueued: "Could not send the report right now.",
    reportJustificationHint: "Optional: what happened? (10–500 characters)",
    overrideCounted: "Proceeding. This override is counted locally.",
    reasonsHeading: "Why",
    warnNoReason: "open TrustLens for details",
    pausedBanner: "Protection paused",
    pair: {
      heading: "Connect TrustLens",
      body: "Connect once and every page you open is checked in real time.",
      oneClick: "Connect in one click",
      oneClickHint: "Opens your TrustLens dashboard and connects this browser. Sign in first if asked.",
      manualToggle: "Have a code? Enter it instead",
      manualBody: "In the dashboard open Developers → Browser extension, choose “Generate pairing code”, and enter the 8-character code here.",
      codeLabel: "Pairing code",
      submit: "Connect",
      working: "Working…",
      connected: "Connected",
      reconnect: "Reconnect TrustLens to keep protecting you.",
      invalidCode: "That code is not valid or has expired. Get a new one from the dashboard.",
      failed: "Could not connect right now. Try again in a moment."
    },
    popup: {
      currentPage: "This page",
      noPage: "Browser pages (new tab, settings, the web store) cannot be checked.",
      watchPage: "Watch this tab for logins and payments",
      watching: "Watching this tab.",
      options: "Settings",
      version: "Version {v}",
      checkingLive: "Checking {host} live…",
      checkingHint: "First visits run a full server-side scan; repeat visits are instant.",
      recheck: "Re-check",
      explainAi: "Explain with AI",
      explainHint: "Opens the report and starts an AI investigation that cites the evidence. The AI never changes the decision.",
      protectionOn: "Real-time protection on",
      protectionOff: "Protection paused",
      connected: "Connected",
      notConnected: "Not connected",
      apiDown: "TrustLens server unreachable",
      scoreLabel: "Risk score",
      findings: "What the checks found",
      noFindings: "No finding from the checks that ran.",
      fromCache: "Saved result · {ago}"
    },
    options: {
      apiStatus: "API status",
      apiUp: "Reachable",
      apiDown: "Unreachable — pages will show “not checked”.",
      pairing: "Pairing",
      unpair: "Disconnect this browser",
      unpaired: "Disconnected. Pages will show “not checked” until you reconnect.",
      clearData: "Clear all local data",
      cleared: "Local data cleared.",
      privacyHeading: "What TrustLens sends",
      privacy: [
        "Sent on a check: the page address, the form's destination address, whether a password field exists, and the payee text the page itself displays.",
        "Never read or sent: anything you type (passwords, one-time codes, card numbers), cookies, page HTML, screenshots, or your browsing history.",
        "The server makes every decision. If it cannot be reached, TrustLens says the page was not checked."
      ]
    }
  };
  var FAILURE_COPY = {
    NOT_PAIRED: "TrustLens is not connected. Connect it in the popup to check pages.",
    RECONNECT: "Reconnect TrustLens to keep protecting you.",
    MISCONFIGURED: "This build needs an updated pairing.",
    RATE_LIMITED: "Too many checks right now — pausing for {n}s.",
    UNAVAILABLE: "TrustLens is unavailable — this page was not checked.",
    TIMEOUT: "TrustLens is unavailable — this page was not checked.",
    BAD_RESPONSE: "TrustLens is unavailable — this page was not checked.",
    CANNOT_CHECK_ADDRESS: "This address can't be checked.",
    CANNOT_CHECK_PAGE: "This page can't be checked.",
    PAUSED: "Protection paused — this page was not checked.",
    STALE: "Re-checking… the last result is more than 10 minutes old.",
    LOCAL_PAGE: "Local and private-network addresses are not checked.",
    OWN_SITE: "This is TrustLens itself, so it is not scanned."
  };
  function fill(template, values) {
    return template.replace(/\{(\w+)\}/g, (m, k) => k in values ? String(values[k]) : m);
  }
  function failureText(code, retryAfter) {
    return fill(FAILURE_COPY[code], { n: retryAfter ?? 60 });
  }
  function relativeAgo(iso, now = Date.now()) {
    if (!iso) return null;
    const t = Date.parse(iso);
    if (Number.isNaN(t)) return null;
    const s = Math.max(0, Math.round((now - t) / 1e3));
    if (s < 60) return "just now";
    const m = Math.round(s / 60);
    if (m < 60) return `${m} min ago`;
    const h = Math.round(m / 60);
    if (h < 24) return `${h} h ago`;
    return `${Math.round(h / 24)} d ago`;
  }

  // src/shared/demo-url.ts
  var HOST_RE = /^(?=.{1,253}$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/i;
  function parseOrigin(origin) {
    if (!origin) return null;
    try {
      const u = new URL(origin);
      return u.protocol === "http:" || u.protocol === "https:" ? u : null;
    } catch {
      return null;
    }
  }
  function toReportedUrl(raw, demoOrigin, base) {
    let u;
    try {
      u = base ? new URL(raw, base) : new URL(raw);
    } catch {
      return null;
    }
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    u.hash = "";
    const demo = parseOrigin(demoOrigin);
    if (demo) {
      if (u.origin === demo.origin && u.pathname.startsWith("/site/")) {
        const rest = u.pathname.slice("/site/".length);
        const slash = rest.indexOf("/");
        const host2 = (slash === -1 ? rest : rest.slice(0, slash)).toLowerCase();
        const path = slash === -1 ? "/" : rest.slice(slash);
        if (HOST_RE.test(host2)) return `https://${host2}${path}${u.search}`;
        return u.toString();
      }
      const isExampleHost = u.hostname === "example" || u.hostname.endsWith(".example");
      if (isExampleHost && u.protocol === "http:" && u.port === demo.port) {
        return `https://${u.hostname}${u.pathname}${u.search}`;
      }
    }
    return u.toString();
  }
  function hostOf(url) {
    if (!url) return null;
    try {
      return new URL(url).hostname || null;
    } catch {
      return null;
    }
  }

  // src/shared/detect.ts
  var PAY_WORDS_RE = /\b(pay|pay now|payment|checkout|check out|donate|upi)\b/i;
  var PAY_PATH_RE = /(^|[/._-])(pay|payment|payments|checkout|donate)([/._-]|$)/i;
  var VPA_TEXT_RE = /(?<![\w.-])([a-z0-9][\w.-]{1,63}@[a-z][a-z-]{1,31})(?![\w-]|\.[a-z])/gi;
  var MAX_PAYEE_LEN = 128;
  function isHidden(el2) {
    return Boolean(el2.closest("[hidden], [aria-hidden='true']"));
  }
  function cleanText(s) {
    return (s ?? "").replace(/\s+/g, " ").trim();
  }
  function labelOf(el2) {
    if (el2 instanceof HTMLInputElement) {
      const t = el2.type.toLowerCase();
      return t === "submit" || t === "button" ? cleanText(el2.getAttribute("value")) : "";
    }
    return cleanText(el2.getAttribute("aria-label")) || cleanText(el2.textContent);
  }
  function resolveUrl(raw, base) {
    try {
      return new URL(raw ?? "", base).toString();
    } catch {
      return null;
    }
  }
  function describeForm(form) {
    const base = form.ownerDocument.baseURI;
    return {
      action: resolveUrl(form.getAttribute("action"), base),
      method: (form.getAttribute("method") ?? "get").toLowerCase(),
      hasPassword: Boolean(form.querySelector('input[type="password"]')),
      fieldTypes: Array.from(form.querySelectorAll("input"), (i) => i.type)
    };
  }
  function payeeFromUpiHref(href) {
    if (!href || !/^upi:/i.test(href)) return null;
    const q = href.indexOf("?");
    if (q === -1) return null;
    const pa = new URLSearchParams(href.slice(q + 1)).get("pa");
    return pa ? cleanText(pa).slice(0, MAX_PAYEE_LEN) || null : null;
  }
  function payeeFromText(text) {
    VPA_TEXT_RE.lastIndex = 0;
    const m = VPA_TEXT_RE.exec(text);
    return m?.[1] ?? null;
  }
  function payeeWithin(scope, allowText) {
    for (const el2 of Array.from(scope.querySelectorAll("[data-payee]"))) {
      if (isHidden(el2)) continue;
      const text = cleanText(el2.textContent);
      if (text && text.length <= MAX_PAYEE_LEN) return text;
    }
    for (const a of Array.from(scope.querySelectorAll('a[href^="upi:" i]'))) {
      const pa = payeeFromUpiHref(a.getAttribute("href"));
      if (pa) return pa;
    }
    if (allowText && scope instanceof Element) {
      const text = visibleText(scope);
      if (PAY_WORDS_RE.test(text)) return payeeFromText(text);
    }
    return null;
  }
  function visibleText(scope, maxChars = 2e4) {
    const doc = scope.ownerDocument;
    const walker = doc.createTreeWalker(scope, NodeFilter.SHOW_TEXT);
    const parts = [];
    let total = 0;
    for (let n = walker.nextNode(); n && total < maxChars; n = walker.nextNode()) {
      const parent = n.parentElement;
      if (!parent || isHidden(parent) || parent.closest("script, style, noscript, template")) continue;
      const t = n.textContent ?? "";
      parts.push(t);
      total += t.length;
    }
    return cleanText(parts.join(" "));
  }
  function findPayee(trigger) {
    const form = trigger.closest("form");
    if (form) {
      const p = payeeWithin(form, true);
      if (p) return p;
    }
    const section = trigger.closest("section, article, [role='main'], main, fieldset");
    if (section) {
      const p = payeeWithin(section, true);
      if (p) return p;
    }
    return payeeWithin(trigger.ownerDocument, false);
  }
  function classifyForm(form, submitter) {
    const meta = describeForm(form);
    if (meta.hasPassword) return "login";
    if (form.querySelector("[data-payee]") || form.querySelector('a[href^="upi:" i]')) return "payment";
    const buttons = submitter ? [submitter] : Array.from(form.querySelectorAll('button:not([type]), button[type="submit"], input[type="submit"]'));
    if (buttons.some((b) => PAY_WORDS_RE.test(labelOf(b)))) return "payment";
    if (meta.action) {
      try {
        if (PAY_PATH_RE.test(new URL(meta.action).pathname)) return "payment";
      } catch {
      }
    }
    return null;
  }
  function detectFormAction(form, submitter) {
    const intent = classifyForm(form, submitter);
    if (!intent) return null;
    const override = submitter?.getAttribute("formaction");
    const destination = override ? resolveUrl(override, form.ownerDocument.baseURI) : describeForm(form).action;
    return { intent, destination, payee: intent === "payment" ? findPayee(submitter ?? form) : null };
  }
  function sameOrigin(a, b) {
    try {
      return new URL(a).origin === new URL(b).origin;
    } catch {
      return false;
    }
  }
  var CLICKABLE = "a[href], button, [role='button'], input[type='submit'], input[type='button']";
  function detectClickAction(target) {
    if (!(target instanceof Element)) return null;
    const el2 = target.closest(CLICKABLE);
    if (!el2) return null;
    const inForm = el2.closest("form");
    const isSubmit = el2 instanceof HTMLButtonElement && (el2.type === "submit" || !el2.getAttribute("type")) || el2 instanceof HTMLInputElement && el2.type === "submit";
    if (inForm && isSubmit) return null;
    const href = el2 instanceof HTMLAnchorElement ? el2.getAttribute("href") : null;
    const upiPayee = payeeFromUpiHref(href);
    if (upiPayee) {
      return { element: el2, action: { intent: "payment", destination: null, payee: upiPayee } };
    }
    if (!PAY_WORDS_RE.test(labelOf(el2))) return null;
    const destination = href ? resolveUrl(href, el2.ownerDocument.baseURI) : null;
    if (destination && !/^https?:/i.test(destination)) return null;
    if (destination && sameOrigin(destination, el2.ownerDocument.baseURI)) return null;
    return { element: el2, action: { intent: "payment", destination, payee: findPayee(el2) } };
  }

  // src/shared/messages.ts
  async function send(msg) {
    try {
      const reply = await chrome.runtime.sendMessage(msg);
      if (!reply || typeof reply !== "object" || !("ok" in reply)) {
        return { ok: false, error: { code: "NO_REPLY", message: "The extension did not respond." } };
      }
      return reply;
    } catch (err) {
      return { ok: false, error: { code: "TRANSPORT", message: err instanceof Error ? err.message : String(err) } };
    }
  }

  // src/shared/assessment.ts
  var strArray = (v) => Array.isArray(v) ? v.filter((x) => typeof x === "string") : [];
  function payeeComparison(a) {
    const payeeFinding = a.findings.find((f) => f.code.startsWith("PAYEE") && Array.isArray(f.expected?.payees)) ?? a.findings.find((f) => Array.isArray(f.expected?.payees));
    const observedFromFinding = payeeFinding && typeof payeeFinding.observed?.payee === "string" ? payeeFinding.observed.payee : null;
    const expectedFromFinding = payeeFinding ? strArray(payeeFinding.expected?.payees) : [];
    return {
      observed: a.action?.payee ?? observedFromFinding,
      expected: expectedFromFinding.length > 0 ? expectedFromFinding : a.action?.expected_destinations ?? []
    };
  }
  function topReasons(a, max = 3) {
    return a.reasons.slice(0, max);
  }

  // src/shared/overlay-model.ts
  var MODE_BY_DECISION = {
    BLOCK: "block",
    WARN: "confirm",
    REVIEW: "confirm",
    ALLOW: "proceed",
    UNKNOWN: "unknown"
  };
  function coverageText(percent) {
    return percent === null ? COPY.coverageMissing : fill(COPY.coverageLine, { n: percent });
  }
  function buildOverlayModel(result, intent, now = Date.now(), pageHost = null) {
    if (result.kind === "failure") {
      return {
        mode: "unknown",
        tone: "UNKNOWN",
        label: DECISION_COPY.UNKNOWN.label,
        title: COPY.couldNotVerify,
        body: `${failureText(result.failure.code, result.failure.retryAfter)} ${COPY.couldNotVerifyBody[intent]}`,
        mismatch: null,
        reasons: [],
        coverageLine: COPY.coverageMissing,
        decidedLine: null,
        fullReportUrl: null,
        appealUrl: null,
        scanId: null,
        observedPayee: null,
        primaryLabel: COPY.goBack,
        secondaryLabel: COPY.continueAnyway,
        secondaryConfirmLabel: null,
        toast: null
      };
    }
    const a = result.assessment;
    const mode = MODE_BY_DECISION[a.decision];
    const org = a.action?.claimed_organisation?.name ?? COPY.unknownOrg;
    const { observed, expected } = payeeComparison(a);
    let mismatch = null;
    if (a.decision === "BLOCK" || a.decision === "WARN") {
      if (intent === "payment" && observed) {
        mismatch = { kind: "payee", observed, org, expected };
      } else if (intent === "login" && a.action?.observed_destination) {
        const dest = hostOf(a.action.observed_destination) ?? a.action.observed_destination;
        mismatch = { kind: "credential", text: fill(COPY.credentialMismatch, { observed: dest, org }) };
      }
    }
    const titles = {
      block: COPY.stopped[intent],
      confirm: a.decision === "REVIEW" ? COPY.review[intent] : COPY.suspicious[intent],
      unknown: COPY.couldNotVerify,
      proceed: DECISION_COPY.ALLOW.label
    };
    const ago = relativeAgo(a.decided_at, now);
    const percent = a.coverage.percent;
    return {
      mode,
      tone: a.decision,
      label: DECISION_COPY[a.decision].label,
      title: titles[mode],
      body: mode === "unknown" ? COPY.couldNotVerifyBody[intent] : null,
      mismatch,
      reasons: topReasons(a),
      coverageLine: coverageText(percent),
      decidedLine: ago ? fill(COPY.decidedAgo, { ago }) : null,
      fullReportUrl: a.scan_id ? fullReportUrl(a.scan_id) : null,
      appealUrl: pageHost && isAppealable(a.decision) ? appealUrl(pageHost) : null,
      scanId: a.scan_id,
      observedPayee: observed,
      primaryLabel: COPY.goBack,
      secondaryLabel: mode === "block" ? COPY.proceedAnyway : mode === "confirm" ? COPY.continue : COPY.continueAnyway,
      secondaryConfirmLabel: mode === "block" ? COPY.proceedConfirm : null,
      toast: mode !== "proceed" ? null : percent === null ? COPY.allowToastNoCoverage : fill(COPY.allowToast, { n: percent })
    };
  }

  // src/shared/tokens.ts
  var LIGHT = {
    background: "#f6f5f1",
    foreground: "#111111",
    surface: "#ffffff",
    "surface-secondary": "#ebe9e3",
    border: "#dad9d3",
    "border-strong": "#c4c2ba",
    muted: "#777777",
    "muted-strong": "#5c5c5c",
    primary: "#171717",
    "primary-foreground": "#ffffff",
    "primary-hover": "#2b2b2b",
    danger: "#c03939",
    "danger-surface": "#f7e9e9",
    warning: "#a87526",
    "warning-surface": "#f6efdf",
    success: "#397653",
    "success-surface": "#e8f0ea",
    unknown: "#626262",
    "unknown-surface": "#ececea",
    "focus-ring": "#171717",
    "focus-offset": "#f6f5f1"
  };
  var DARK = {
    background: "#090909",
    foreground: "#f2f1ed",
    surface: "#151515",
    "surface-secondary": "#202020",
    border: "#303030",
    "border-strong": "#3d3d3d",
    muted: "#999999",
    "muted-strong": "#b4b4b4",
    primary: "#f2f1ed",
    "primary-foreground": "#111111",
    "primary-hover": "#e2e1db",
    danger: "#e07a7a",
    "danger-surface": "#2a1a1a",
    warning: "#d3a45e",
    "warning-surface": "#2a2318",
    success: "#7fb894",
    "success-surface": "#17241c",
    unknown: "#9a9a9a",
    "unknown-surface": "#1d1d1d",
    "focus-ring": "#f2f1ed",
    "focus-offset": "#090909"
  };
  var RADIUS = { sm: "4px", md: "6px", lg: "10px" };
  var FONT_SANS = 'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
  var FONT_MONO = 'ui-monospace, "SFMono-Regular", "Cascadia Mono", Consolas, "Liberation Mono", monospace';
  var SHADOW_MODAL = "0 24px 48px -24px rgb(0 0 0 / 0.25)";
  var Z_TOP = 2147483647;
  var DECISION_TOKENS = {
    BLOCK: { text: "danger", surface: "danger-surface" },
    WARN: { text: "warning", surface: "warning-surface" },
    ALLOW: { text: "success", surface: "success-surface" },
    REVIEW: { text: "unknown", surface: "unknown-surface" },
    UNKNOWN: { text: "unknown", surface: "unknown-surface" }
  };
  function vars(t) {
    return Object.entries(t).map(([k, v]) => `--${k}:${v};`).join("");
  }
  function tokensCss(selector) {
    return `${selector}{${vars(LIGHT)}--radius-sm:${RADIUS.sm};--radius-md:${RADIUS.md};--radius-lg:${RADIUS.lg};--font-sans:${FONT_SANS};--font-mono:${FONT_MONO};--shadow-modal:${SHADOW_MODAL};}@media (prefers-color-scheme: dark){${selector}{${vars(DARK)}}}`;
  }

  // src/content/overlay.ts
  var SVG_NS = "http://www.w3.org/2000/svg";
  var SHIELD = "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z";
  var ICONS = {
    "shield-x": [SHIELD, "m14.5 9.5-5 5", "m9.5 9.5 5 5"],
    "shield-alert": [SHIELD, "M12 8v4", "M12 16h.01"],
    "shield-check": [SHIELD, "m9 12 2 2 4-4"],
    "shield-question": [SHIELD, "M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3", "M12 17h.01"],
    search: ["M11 3a8 8 0 1 0 0 16a8 8 0 1 0 0-16z", "m21 21-4.3-4.3"]
  };
  function icon(name, size = 16) {
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("width", String(size));
    svg.setAttribute("height", String(size));
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "1.5");
    svg.setAttribute("stroke-linecap", "round");
    svg.setAttribute("stroke-linejoin", "round");
    svg.setAttribute("aria-hidden", "true");
    for (const d of ICONS[name] ?? []) {
      const p = document.createElementNS(SVG_NS, "path");
      p.setAttribute("d", d);
      svg.appendChild(p);
    }
    return svg;
  }
  var STYLES = `
${tokensCss(":host")}
:host{all:initial;position:fixed;inset:0;z-index:${Z_TOP};pointer-events:none;font-family:var(--font-sans);color:var(--foreground);}
*{box-sizing:border-box;margin:0;padding:0;font:inherit;color:inherit;}
.scrim{position:fixed;inset:0;pointer-events:auto;display:flex;align-items:center;justify-content:center;padding:16px;background:color-mix(in srgb, var(--foreground) 45%, transparent);}
.panel{width:100%;max-width:440px;max-height:90vh;overflow:auto;background:var(--surface);color:var(--foreground);border:1px solid var(--border);border-radius:var(--radius-lg);box-shadow:var(--shadow-modal);font-size:14px;line-height:1.55;}
.head{display:flex;align-items:center;gap:8px;padding:12px 20px;border-bottom:1px solid var(--border);font-size:12px;font-weight:500;letter-spacing:.02em;}
.head .brand{color:var(--muted-strong);}
.head .label{display:inline-flex;align-items:center;gap:6px;padding:2px 8px;border-radius:999px;}
.body{padding:20px;display:flex;flex-direction:column;gap:16px;}
h2{font-size:18px;line-height:1.35;font-weight:500;}
.mismatch{display:flex;flex-direction:column;gap:4px;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius-md);background:var(--surface-secondary);}
.mismatch .k{color:var(--muted-strong);font-size:13px;}
.mismatch .v{font-family:var(--font-mono);font-size:15px;line-height:1.4;word-break:break-all;margin-bottom:6px;}
.v.observed{color:var(--danger);font-weight:500;}
.v.expected{color:var(--foreground);}
.reasons h3{font-size:12px;font-weight:500;letter-spacing:.02em;color:var(--muted-strong);margin-bottom:4px;}
.reasons ul{padding-left:18px;display:flex;flex-direction:column;gap:4px;}
.note{font-size:12px;line-height:1.4;color:var(--muted-strong);}
.actions{display:flex;flex-wrap:wrap;align-items:center;gap:8px 16px;}
.links{display:flex;flex-wrap:wrap;gap:8px 16px;font-size:13px;}
button,a{cursor:pointer;border-radius:var(--radius-md);text-decoration:none;}
button:focus-visible,a:focus-visible{outline:2px solid var(--focus-ring);outline-offset:2px;}
.primary{background:var(--primary);color:var(--primary-foreground);border:1px solid var(--primary);height:36px;padding:0 16px;font-weight:500;}
.primary:hover{background:var(--primary-hover);}
.secondary{background:transparent;color:var(--foreground);border:1px solid var(--border-strong);height:36px;padding:0 16px;}
.linkbtn{background:none;border:none;padding:4px 0;color:var(--muted-strong);text-decoration:underline;text-underline-offset:2px;}
.linkbtn.armed{color:var(--danger);border:1px solid var(--danger);padding:0 12px;height:36px;text-decoration:none;}
.link{color:var(--foreground);text-decoration:underline;text-underline-offset:2px;}
.link.subtle{color:var(--muted-strong);font-size:12px;}
.status{font-size:12px;color:var(--muted-strong);min-height:1em;}
.toast,.banner{position:fixed;pointer-events:auto;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-md);display:flex;align-items:center;gap:8px;font-size:13px;line-height:1.4;max-width:calc(100vw - 32px);}
.toast{right:16px;bottom:16px;padding:10px 14px;}
.banner{right:16px;top:16px;min-height:44px;padding:6px 8px 6px 12px;}
.banner .msg{overflow:hidden;text-overflow:ellipsis;}
.banner button{height:28px;padding:0 10px;font-size:12px;}
.spin{width:14px;height:14px;border:2px solid var(--border-strong);border-top-color:var(--foreground);border-radius:50%;animation:s 0.8s linear infinite;}
@keyframes s{to{transform:rotate(360deg)}}
@media (prefers-reduced-motion: reduce){.spin{animation:none}}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap;}
`;
  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== void 0) e.textContent = text;
    return e;
  }
  var host = null;
  var root = null;
  function ensureRoot() {
    if (root && host?.isConnected) return root;
    host = document.createElement("trustlens-overlay");
    root = host.attachShadow({ mode: "closed" });
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(STYLES);
      root.adoptedStyleSheets = [sheet];
    } catch {
      const style = document.createElement("style");
      style.textContent = STYLES;
      root.appendChild(style);
    }
    document.documentElement.appendChild(host);
    return root;
  }
  function clear(selector) {
    root?.querySelectorAll(selector).forEach((n) => n.remove());
  }
  function toneStyle(node, tone) {
    const t = DECISION_TOKENS[tone];
    node.style.setProperty("color", `var(--${t.text})`);
    node.style.setProperty("background", `var(--${t.surface})`);
  }
  function header(tone, label) {
    const head = el("div", "head");
    head.appendChild(el("span", "brand", COPY.product));
    const badge = el("span", "label");
    toneStyle(badge, tone);
    badge.appendChild(icon(DECISION_COPY[tone].icon, 14));
    badge.appendChild(el("span", void 0, label));
    head.appendChild(badge);
    return head;
  }
  function showChecking(intent, onCancel) {
    const r = ensureRoot();
    clear(".scrim");
    const scrim = el("div", "scrim");
    const panel = el("div", "panel");
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "true");
    panel.setAttribute("aria-busy", "true");
    panel.appendChild(header("UNKNOWN", COPY.product));
    const body = el("div", "body");
    const row = el("div", "actions");
    row.appendChild(el("span", "spin"));
    const h = el("h2", void 0, COPY.checking[intent]);
    h.id = "tl-title";
    row.appendChild(h);
    body.appendChild(row);
    const cancel = el("button", "secondary", COPY.goBack);
    cancel.type = "button";
    cancel.addEventListener("click", onCancel);
    body.appendChild(cancel);
    panel.setAttribute("aria-labelledby", "tl-title");
    panel.appendChild(body);
    scrim.appendChild(panel);
    r.appendChild(scrim);
    cancel.focus({ preventScroll: true });
    return () => scrim.remove();
  }
  function showDecision(model, handlers) {
    const r = ensureRoot();
    clear(".scrim");
    const previouslyFocused = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    return new Promise((resolve) => {
      const scrim = el("div", "scrim");
      const panel = el("div", "panel");
      panel.setAttribute("role", model.mode === "block" ? "alertdialog" : "dialog");
      panel.setAttribute("aria-modal", "true");
      panel.setAttribute("aria-labelledby", "tl-title");
      panel.setAttribute("aria-describedby", "tl-desc");
      panel.appendChild(header(model.tone, model.label));
      const body = el("div", "body");
      const title = el("h2", void 0, model.title);
      title.id = "tl-title";
      body.appendChild(title);
      const desc = el("div");
      desc.id = "tl-desc";
      desc.style.setProperty("display", "contents");
      if (model.mismatch?.kind === "payee") {
        const m = model.mismatch;
        const box = el("div", "mismatch");
        box.appendChild(el("span", "k", "This page asks you to pay"));
        box.appendChild(el("span", "v observed", m.observed));
        if (m.expected.length > 0) {
          box.appendChild(el("span", "k", `${m.org} has registered`));
          box.appendChild(el("span", "v expected", m.expected.join(", ")));
        }
        desc.appendChild(box);
      } else if (model.mismatch?.kind === "credential") {
        const box = el("div", "mismatch");
        box.appendChild(el("span", void 0, model.mismatch.text));
        desc.appendChild(box);
      }
      if (model.body) desc.appendChild(el("p", void 0, model.body));
      if (model.reasons.length > 0) {
        const sec = el("div", "reasons");
        sec.appendChild(el("h3", void 0, COPY.reasonsHeading));
        const ul = el("ul");
        for (const reason of model.reasons) ul.appendChild(el("li", void 0, reason));
        sec.appendChild(ul);
        desc.appendChild(sec);
      }
      body.appendChild(desc);
      const actions = el("div", "actions");
      const back = el("button", "primary", model.primaryLabel);
      back.type = "button";
      const proceedBtn = el("button", model.mode === "block" ? "linkbtn" : "secondary", model.secondaryLabel);
      proceedBtn.type = "button";
      actions.append(back, proceedBtn);
      body.appendChild(actions);
      const links = el("div", "links");
      if (model.fullReportUrl) {
        const a = el("a", "link", COPY.fullReport);
        a.href = model.fullReportUrl;
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        links.appendChild(a);
      }
      const reportBtn = el("button", "linkbtn", COPY.reportPage);
      reportBtn.type = "button";
      links.appendChild(reportBtn);
      if (model.appealUrl) {
        const appeal = el("a", "link subtle", COPY.appealSite);
        appeal.href = model.appealUrl;
        appeal.target = "_blank";
        appeal.rel = "noopener noreferrer";
        links.appendChild(appeal);
      }
      body.appendChild(links);
      const status = el("p", "status");
      status.setAttribute("role", "status");
      body.appendChild(status);
      const foot = [model.coverageLine, model.decidedLine].filter(Boolean).join(" ");
      body.appendChild(el("p", "note", foot));
      panel.appendChild(body);
      scrim.appendChild(panel);
      r.appendChild(scrim);
      const finish = (choice) => {
        document.removeEventListener("keydown", onKey, true);
        scrim.remove();
        previouslyFocused?.focus({ preventScroll: true });
        resolve(choice);
      };
      const focusables = () => Array.from(panel.querySelectorAll("button, a[href]"));
      const onKey = (e) => {
        if (e.key === "Escape") {
          e.preventDefault();
          e.stopPropagation();
          finish("back");
        } else if (e.key === "Tab") {
          const list = focusables();
          if (list.length === 0) return;
          const active = r.activeElement;
          const idx = list.indexOf(active);
          const next = e.shiftKey ? idx <= 0 ? list.length - 1 : idx - 1 : idx === list.length - 1 ? 0 : idx + 1;
          e.preventDefault();
          list[next]?.focus();
        }
      };
      document.addEventListener("keydown", onKey, true);
      back.addEventListener("click", () => finish("back"));
      let armed = false;
      proceedBtn.addEventListener("click", () => {
        if (model.secondaryConfirmLabel && !armed) {
          armed = true;
          proceedBtn.textContent = model.secondaryConfirmLabel;
          proceedBtn.classList.add("armed");
          proceedBtn.focus();
          return;
        }
        finish("proceed");
      });
      reportBtn.addEventListener("click", async () => {
        reportBtn.disabled = true;
        status.textContent = COPY.pair.working;
        status.textContent = await handlers.onReport();
      });
      back.focus({ preventScroll: true });
    });
  }
  function showToast(text, ms = 6e3) {
    const r = ensureRoot();
    clear(".toast");
    const t = el("div", "toast");
    t.setAttribute("role", "status");
    const ic = el("span");
    ic.style.setProperty("color", "var(--success)");
    ic.appendChild(icon("shield-check", 16));
    t.append(ic, el("span", void 0, text));
    r.appendChild(t);
    setTimeout(() => t.remove(), ms);
  }
  function showWarnBanner(text, reasons, onDismiss) {
    const r = ensureRoot();
    clear(".banner");
    const b = el("div", "banner");
    b.setAttribute("role", "status");
    toneStyle(b, "WARN");
    b.appendChild(icon("shield-alert", 16));
    const msg = el("span", "msg", text);
    b.appendChild(msg);
    if (reasons.length > 1) {
      const details = el("button", "secondary", COPY.details);
      details.type = "button";
      details.addEventListener("click", () => {
        msg.textContent = reasons.join(" · ");
        details.remove();
      });
      b.appendChild(details);
    }
    const dismiss = el("button", "secondary", COPY.dismiss);
    dismiss.type = "button";
    dismiss.addEventListener("click", () => {
      b.remove();
      onDismiss();
    });
    b.appendChild(dismiss);
    r.appendChild(b);
  }

  // src/content/content.ts
  var MARK = "__trustlensContentLoaded";
  function init() {
    const releasedOnce = /* @__PURE__ */ new WeakSet();
    let busy = false;
    let enabled = true;
    async function handleAction(action, proceed) {
      busy = true;
      let cancelled = false;
      const closeChecking = showChecking(action.intent, () => {
        cancelled = true;
        closeChecking();
        busy = false;
      });
      const reply = await send({
        type: "ACTION_INTENT",
        url: location.href,
        intent: action.intent,
        formAction: action.destination ?? void 0,
        payee: action.payee ?? void 0
      });
      if (cancelled) return;
      closeChecking();
      const result = reply.ok ? reply.data : { kind: "failure", failure: { code: "UNAVAILABLE" }, checkedAt: Date.now() };
      if (result.kind === "failure" && (result.failure.code === "PAUSED" || result.failure.code === "LOCAL_PAGE" || result.failure.code === "OWN_SITE")) {
        busy = false;
        proceed();
        return;
      }
      const pageHost = hostOf(toReportedUrl(location.href, DEMO_SITES_ORIGIN));
      const model = buildOverlayModel(result, action.intent, Date.now(), pageHost);
      if (model.mode === "proceed") {
        if (model.toast) showToast(model.toast);
        busy = false;
        proceed();
        return;
      }
      const choice = await showDecision(model, {
        onReport: async () => {
          const r = await send({
            type: "REPORT",
            url: location.href,
            intent: action.intent,
            observedPayee: model.observedPayee ?? void 0,
            scanId: model.scanId ?? void 0
          });
          return r.ok ? COPY.reportSent : COPY.reportQueued;
        }
      });
      if (model.mode === "block") void send({ type: "RECORD_OVERRIDE", taken: choice === "proceed" });
      busy = false;
      if (choice === "proceed") proceed();
    }
    window.addEventListener(
      "submit",
      (e) => {
        if (!enabled) return;
        const form = e.target;
        if (!(form instanceof HTMLFormElement)) return;
        if (releasedOnce.has(form)) {
          releasedOnce.delete(form);
          return;
        }
        const action = detectFormAction(form, e.submitter);
        if (!action) return;
        e.preventDefault();
        e.stopImmediatePropagation();
        if (busy) return;
        const submitter = e.submitter;
        void handleAction(action, () => {
          releasedOnce.add(form);
          if (submitter instanceof HTMLElement && submitter.isConnected && form.contains(submitter)) {
            form.requestSubmit(submitter);
          } else {
            form.requestSubmit();
          }
        });
      },
      true
    );
    window.addEventListener(
      "click",
      (e) => {
        if (!enabled || e.button !== 0) return;
        const hit = detectClickAction(e.target);
        if (!hit) return;
        if (releasedOnce.has(hit.element)) {
          releasedOnce.delete(hit.element);
          return;
        }
        e.preventDefault();
        e.stopImmediatePropagation();
        if (busy) return;
        void handleAction(hit.action, () => {
          releasedOnce.add(hit.element);
          hit.element.click();
        });
      },
      true
    );
    void (async () => {
      const settings = await send({ type: "GET_SETTINGS" });
      if (settings.ok && !settings.data.enabled) {
        enabled = false;
        return;
      }
      const status = await send({ type: "PAGE_READY", url: location.href });
      if (!status.ok || status.data.kind !== "assessment") return;
      const a = status.data.assessment;
      if (a.decision !== "WARN") return;
      const host2 = location.hostname;
      const dismissed = await send({ type: "IS_WARN_DISMISSED", host: host2 });
      if (dismissed.ok && dismissed.data) return;
      const reason = a.reasons[0] ?? COPY.warnNoReason;
      showWarnBanner(fill(DECISION_COPY.WARN.headline, { reason }), a.reasons.slice(0, 3), () => {
        void send({ type: "DISMISS_WARN", host: host2 });
      });
    })();
  }
  var g = globalThis;
  if (!g[MARK]) {
    g[MARK] = true;
    init();
  }
})();
