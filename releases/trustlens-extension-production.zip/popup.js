"use strict";
(() => {
  // src/shared/assessment.ts
  function topReasons(a, max = 3) {
    return a.reasons.slice(0, max);
  }

  // src/shared/copy.ts
  var DECISION_COPY = {
    BLOCK: {
      label: "Blocked",
      headline: "Blocked: {reason}",
      srText: "TrustLens decision: blocked.",
      icon: "shield-x",
      badge: "!"
    },
    WARN: {
      label: "Suspicious",
      headline: "Suspicious: {reason}",
      srText: "TrustLens decision: suspicious.",
      icon: "shield-alert",
      badge: "!"
    },
    ALLOW: {
      label: "No known threat",
      headline: "No known threat ({coverage}% checked)",
      srText: "TrustLens decision: no known threat in the checks that ran. This is not a guarantee.",
      icon: "shield-check",
      badge: ""
    },
    REVIEW: {
      label: "Needs review",
      headline: "Needs review: not enough evidence",
      srText: "TrustLens decision: needs review. Signals conflict or coverage is too low.",
      icon: "search",
      badge: "?"
    },
    UNKNOWN: {
      label: "Not verified",
      headline: "Not verified: {reason}",
      srText: "TrustLens could not verify this page. It was not checked.",
      icon: "shield-question",
      badge: "?"
    }
  };
  var COPY = {
    product: "TrustLens",
    allowSublabel: "Based on {n}% coverage. This is not a guarantee.",
    allowToast: "No known threat in the checks that ran · coverage {n}%",
    allowToastNoCoverage: "No known threat in the checks that ran · coverage not reported",
    coverageLine: "We checked {n}% of signal groups.",
    coverageMissing: "Coverage was not reported for this check.",
    decidedAgo: "Decided {ago}.",
    checking: { payment: "Checking this payment…", login: "Checking this login…" },
    stopped: { payment: "Payment stopped", login: "Login stopped" },
    suspicious: { payment: "Check this payment first", login: "Check this login first" },
    review: { payment: "This payment needs review", login: "This login needs review" },
    couldNotVerify: "Could not verify this page",
    couldNotVerifyBody: {
      payment: "TrustLens could not check this payment. It was not checked — decide for yourself.",
      login: "TrustLens could not check this login. It was not checked — decide for yourself."
    },
    payeeMismatch: "This page asks you to pay {observed}. {org} has registered {expected}.",
    payeeObservedOnly: "This page asks you to pay {observed}.",
    credentialMismatch: "This login form sends your password to {observed}, which is not an approved {org} login endpoint.",
    unknownOrg: "The organisation this page claims to be",
    goBack: "Go back",
    proceedAnyway: "Proceed anyway",
    proceedConfirm: "I understand the risk — proceed",
    continue: "Continue",
    continueAnyway: "Continue without a check",
    details: "Details",
    dismiss: "Dismiss",
    fullReport: "Full report",
    reportPage: "Report this page",
    appealSite: "Is this your site? Appeal this decision",
    reportSite: "Report this site",
    reportSent: "Report sent. You'll see updates in the dashboard.",
    reportQueued: "Could not send the report right now.",
    reportJustificationHint: "Optional: what happened? (10–500 characters)",
    overrideCounted: "Proceeding. This override is counted locally.",
    reasonsHeading: "Why",
    warnNoReason: "open TrustLens for details",
    pausedBanner: "Protection paused",
    pair: {
      heading: "Connect TrustLens",
      body: "Connect once and every page you open is checked in real time.",
      oneClick: "Connect in one click",
      oneClickHint: "Opens your TrustLens dashboard and connects this browser. Sign in first if asked.",
      manualToggle: "Have a code? Enter it instead",
      manualBody: "In the dashboard open Developers → Browser extension, choose “Generate pairing code”, and enter the 8-character code here.",
      codeLabel: "Pairing code",
      submit: "Connect",
      working: "Working…",
      connected: "Connected",
      reconnect: "Reconnect TrustLens to keep protecting you.",
      invalidCode: "That code is not valid or has expired. Get a new one from the dashboard.",
      failed: "Could not connect right now. Try again in a moment."
    },
    popup: {
      currentPage: "This page",
      noPage: "Browser pages (new tab, settings, the web store) cannot be checked.",
      watchPage: "Watch this tab for logins and payments",
      watching: "Watching this tab.",
      options: "Settings",
      version: "Version {v}",
      checkingLive: "Checking {host} live…",
      checkingHint: "First visits run a full server-side scan; repeat visits are instant.",
      recheck: "Re-check",
      explainAi: "Explain with AI",
      explainHint: "Opens the report and starts an AI investigation that cites the evidence. The AI never changes the decision.",
      protectionOn: "Real-time protection on",
      protectionOff: "Protection paused",
      connected: "Connected",
      notConnected: "Not connected",
      apiDown: "TrustLens server unreachable",
      scoreLabel: "Risk score",
      findings: "What the checks found",
      noFindings: "No finding from the checks that ran.",
      fromCache: "Saved result · {ago}"
    },
    options: {
      apiStatus: "API status",
      apiUp: "Reachable",
      apiDown: "Unreachable — pages will show “not checked”.",
      pairing: "Pairing",
      unpair: "Disconnect this browser",
      unpaired: "Disconnected. Pages will show “not checked” until you reconnect.",
      clearData: "Clear all local data",
      cleared: "Local data cleared.",
      privacyHeading: "What TrustLens sends",
      privacy: [
        "Sent on a check: the page address, the form's destination address, whether a password field exists, and the payee text the page itself displays.",
        "Never read or sent: anything you type (passwords, one-time codes, card numbers), cookies, page HTML, screenshots, or your browsing history.",
        "The server makes every decision. If it cannot be reached, TrustLens says the page was not checked."
      ]
    }
  };
  var FAILURE_COPY = {
    NOT_PAIRED: "TrustLens is not connected. Connect it in the popup to check pages.",
    RECONNECT: "Reconnect TrustLens to keep protecting you.",
    MISCONFIGURED: "This build needs an updated pairing.",
    RATE_LIMITED: "Too many checks right now — pausing for {n}s.",
    UNAVAILABLE: "TrustLens is unavailable — this page was not checked.",
    TIMEOUT: "TrustLens is unavailable — this page was not checked.",
    BAD_RESPONSE: "TrustLens is unavailable — this page was not checked.",
    CANNOT_CHECK_ADDRESS: "This address can't be checked.",
    CANNOT_CHECK_PAGE: "This page can't be checked.",
    PAUSED: "Protection paused — this page was not checked.",
    STALE: "Re-checking… the last result is more than 10 minutes old.",
    LOCAL_PAGE: "Local and private-network addresses are not checked.",
    OWN_SITE: "This is TrustLens itself, so it is not scanned."
  };
  var NEUTRAL_FAILURES = /* @__PURE__ */ new Set(["LOCAL_PAGE", "OWN_SITE", "PAUSED", "NOT_PAIRED"]);
  function fill(template, values) {
    return template.replace(/\{(\w+)\}/g, (m, k) => k in values ? String(values[k]) : m);
  }
  function failureText(code, retryAfter) {
    return fill(FAILURE_COPY[code], { n: retryAfter ?? 60 });
  }
  function relativeAgo(iso, now = Date.now()) {
    if (!iso) return null;
    const t = Date.parse(iso);
    if (Number.isNaN(t)) return null;
    const s = Math.max(0, Math.round((now - t) / 1e3));
    if (s < 60) return "just now";
    const m = Math.round(s / 60);
    if (m < 60) return `${m} min ago`;
    const h2 = Math.round(m / 60);
    if (h2 < 24) return `${h2} h ago`;
    return `${Math.round(h2 / 24)} d ago`;
  }

  // src/shared/config.ts
  var API_BASE_URL = "https://trustlens-api-m65a.onrender.com".replace(/\/+$/, "");
  var WEB_BASE_URL = "https://trustlens-web-three.vercel.app".replace(/\/+$/, "");
  var DEMO_SITES_ORIGIN = "https://trustlens-demo-northstar.vercel.app";
  var EXT_VERSION = "0.4.1";
  function fullReportUrl(scanId) {
    return `${WEB_BASE_URL}/app/scan/${encodeURIComponent(scanId)}`;
  }
  function aiExplainUrl(scanId) {
    return `${WEB_BASE_URL}/app/scan/${encodeURIComponent(scanId)}?investigate=1`;
  }
  var CONNECT_URL = `${WEB_BASE_URL}/app/developers?connect=extension`;
  function appealUrl(host) {
    return `${WEB_BASE_URL}/appeal?domain=${encodeURIComponent(host)}`;
  }
  function isAppealable(decision) {
    return decision === "BLOCK" || decision === "WARN";
  }

  // src/shared/demo-url.ts
  var HOST_RE = /^(?=.{1,253}$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/i;
  function parseOrigin(origin) {
    if (!origin) return null;
    try {
      const u = new URL(origin);
      return u.protocol === "http:" || u.protocol === "https:" ? u : null;
    } catch {
      return null;
    }
  }
  function toReportedUrl(raw, demoOrigin, base) {
    let u;
    try {
      u = base ? new URL(raw, base) : new URL(raw);
    } catch {
      return null;
    }
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    u.hash = "";
    const demo = parseOrigin(demoOrigin);
    if (demo) {
      if (u.origin === demo.origin && u.pathname.startsWith("/site/")) {
        const rest = u.pathname.slice("/site/".length);
        const slash = rest.indexOf("/");
        const host = (slash === -1 ? rest : rest.slice(0, slash)).toLowerCase();
        const path = slash === -1 ? "/" : rest.slice(slash);
        if (HOST_RE.test(host)) return `https://${host}${path}${u.search}`;
        return u.toString();
      }
      const isExampleHost = u.hostname === "example" || u.hostname.endsWith(".example");
      if (isExampleHost && u.protocol === "http:" && u.port === demo.port) {
        return `https://${u.hostname}${u.pathname}${u.search}`;
      }
    }
    return u.toString();
  }
  function hostOf(url) {
    if (!url) return null;
    try {
      return new URL(url).hostname || null;
    } catch {
      return null;
    }
  }

  // src/shared/messages.ts
  async function send(msg) {
    try {
      const reply = await chrome.runtime.sendMessage(msg);
      if (!reply || typeof reply !== "object" || !("ok" in reply)) {
        return { ok: false, error: { code: "NO_REPLY", message: "The extension did not respond." } };
      }
      return reply;
    } catch (err) {
      return { ok: false, error: { code: "TRANSPORT", message: err instanceof Error ? err.message : String(err) } };
    }
  }

  // src/shared/tokens.ts
  var DECISION_TOKENS = {
    BLOCK: { text: "danger", surface: "danger-surface" },
    WARN: { text: "warning", surface: "warning-surface" },
    ALLOW: { text: "success", surface: "success-surface" },
    REVIEW: { text: "unknown", surface: "unknown-surface" },
    UNKNOWN: { text: "unknown", surface: "unknown-surface" }
  };

  // src/shared/page.ts
  function h(tag, props = {}, children = []) {
    const e = document.createElement(tag);
    if (props.className) e.className = props.className;
    if (props.text !== void 0) e.textContent = props.text;
    for (const [k, v] of Object.entries(props.attrs ?? {})) e.setAttribute(k, v);
    for (const c of children) if (c) e.appendChild(c);
    return e;
  }
  function byId(id) {
    const e = document.getElementById(id);
    if (!e) throw new Error(`missing #${id}`);
    return e;
  }

  // src/shared/pair-form.ts
  function deviceName() {
    const ua = navigator.userAgent;
    const os = /Windows/.test(ua) ? "Windows" : /Mac OS X/.test(ua) ? "macOS" : /Linux/.test(ua) ? "Linux" : "desktop";
    return `Chrome on ${os}`;
  }
  function wirePairForm(form, input, errorEl, onPaired) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const button = form.querySelector("button[type=submit]");
      errorEl.textContent = "";
      if (button) {
        button.disabled = true;
        button.textContent = COPY.pair.working;
      }
      const code = input.value;
      const reply = await send({ type: "PAIR", code, deviceName: deviceName() });
      if (button) {
        button.disabled = false;
        button.textContent = COPY.pair.submit;
      }
      if (reply.ok) {
        input.value = "";
        onPaired(reply.data);
        return;
      }
      errorEl.textContent = reply.error.code === "INVALID_CODE" ? COPY.pair.invalidCode : COPY.pair.failed;
    });
  }

  // src/popup/popup.ts
  var SVG = "http://www.w3.org/2000/svg";
  var pageStatus = byId("page-status");
  var pageHost = byId("page-host");
  var recheck = byId("recheck");
  var pairCard = byId("pair-card");
  var reportCard = byId("report-card");
  var watchBtn = byId("watch");
  var watchStatus = byId("watch-status");
  var protect = byId("protect");
  var chip = byId("conn-chip");
  byId("version").textContent = fill(COPY.popup.version, { v: EXT_VERSION });
  byId("pair-body").textContent = COPY.pair.body;
  byId("connect-one-click").textContent = COPY.pair.oneClick;
  byId("connect-hint").textContent = COPY.pair.oneClickHint;
  byId("manual-toggle").textContent = COPY.pair.manualToggle;
  byId("manual-body").textContent = COPY.pair.manualBody;
  byId("report-hint").textContent = COPY.reportJustificationHint;
  watchBtn.textContent = COPY.popup.watchPage;
  byId("open-options").addEventListener("click", () => void chrome.runtime.openOptionsPage());
  byId("connect-one-click").addEventListener("click", () => void chrome.tabs.create({ url: CONNECT_URL }));
  var activeTab;
  var lastResult = null;
  var paired = false;
  var ticker = null;
  function svg(tag, attrs) {
    const e = document.createElementNS(SVG, tag);
    for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
    return e;
  }
  function scoreRing(decision, score) {
    const size = 64;
    const r = 27;
    const c = 2 * Math.PI * r;
    const has = typeof score === "number" && Number.isFinite(score);
    const v = has ? Math.max(0, Math.min(100, Math.round(score))) : 0;
    const wrap = h("div", { className: "ring", attrs: { role: "img", "aria-label": has ? `${COPY.popup.scoreLabel} ${v} of 100` : "Risk score not reported" } });
    const s = svg("svg", { width: String(size), height: String(size), viewBox: `0 0 ${size} ${size}`, "aria-hidden": "true" });
    s.appendChild(svg("circle", { cx: "32", cy: "32", r: String(r), fill: "none", stroke: "var(--surface-secondary)", "stroke-width": "6" }));
    const arc = svg("circle", {
      class: "arc",
      cx: "32",
      cy: "32",
      r: String(r),
      fill: "none",
      stroke: `var(--${DECISION_TOKENS[decision].text})`,
      "stroke-width": "6",
      "stroke-linecap": "round",
      "stroke-dasharray": String(c),
      "stroke-dashoffset": String(c)
    });
    s.appendChild(arc);
    wrap.appendChild(s);
    const num = h("div", { className: "num" }, [document.createTextNode(has ? String(v) : "—"), h("small", { text: "/100" })]);
    wrap.appendChild(num);
    requestAnimationFrame(() => arc.setAttribute("stroke-dashoffset", String(c * (1 - v / 100))));
    return wrap;
  }
  function renderAssessment(a, checkedAt) {
    const d = a.decision;
    const copy = DECISION_COPY[d];
    const reasons = topReasons(a);
    const label = h("p", { className: "v-label", text: copy.label, attrs: { "aria-label": copy.srText } });
    label.style.setProperty("color", `var(--${DECISION_TOKENS[d].text})`);
    const reasonText = d === "ALLOW" ? fill(COPY.allowSublabel, { n: a.coverage.percent ?? "?" }) : reasons[0] ?? copy.headline.replace(": {reason}", "");
    const box = h("div", { className: "scanning" }, [
      h("div", { className: "verdict" }, [scoreRing(d, a.risk_score), h("div", { className: "v-text" }, [label, h("p", { className: "v-reason", text: reasonText })])])
    ]);
    const pct = a.coverage.percent;
    const meter = h("div", { className: "meter", attrs: { role: "meter", "aria-label": "Coverage", "aria-valuemin": "0", "aria-valuemax": "100", "aria-valuenow": String(pct ?? 0) } }, [h("span")]);
    meter.firstElementChild.style.setProperty("width", `${pct ?? 0}%`);
    box.appendChild(
      h("div", { className: "cov" }, [
        h("div", { className: "cov-top" }, [h("span", { text: "Coverage" }), h("span", { text: pct === null ? "not reported" : `${pct}% checked` })]),
        meter
      ])
    );
    const items = a.findings.length ? a.findings.slice(0, 4).map((f) => h("li", {}, [h("span", { className: "sev", attrs: { "data-s": f.severity ?? "info", "aria-hidden": "true" } }), h("span", { text: f.title })])) : reasons.slice(d === "ALLOW" ? 0 : 1).map((r) => h("li", {}, [h("span", { className: "sev", attrs: { "aria-hidden": "true" } }), h("span", { text: r })]));
    box.appendChild(h("p", { className: "muted", text: COPY.popup.findings }));
    box.appendChild(items.length ? h("ul", { className: "findings" }, items) : h("p", { className: "neutral", text: COPY.popup.noFindings }));
    const actions = h("div", { className: "actions" });
    if (a.scan_id) {
      actions.appendChild(h("a", { className: "btn primary", text: COPY.fullReport, attrs: { href: fullReportUrl(a.scan_id), target: "_blank", rel: "noopener noreferrer" } }));
      actions.appendChild(
        h("a", { className: "btn", text: COPY.popup.explainAi, attrs: { href: aiExplainUrl(a.scan_id), target: "_blank", rel: "noopener noreferrer", title: COPY.popup.explainHint } })
      );
    }
    const host = hostOf(toReportedUrl(activeTab?.url ?? knownUrl ?? "", DEMO_SITES_ORIGIN));
    if (host && isAppealable(d)) {
      actions.appendChild(h("a", { className: "btn", text: "Appeal", attrs: { href: appealUrl(host), target: "_blank", rel: "noopener noreferrer", title: COPY.appealSite } }));
    }
    box.appendChild(actions);
    const ago = relativeAgo(a.decided_at, Date.now());
    const saved = Date.now() - checkedAt > 5e3;
    box.appendChild(h("p", { className: "muted tiny", text: [saved ? fill(COPY.popup.fromCache, { ago: ago ?? "just now" }) : ago ? fill(COPY.decidedAgo, { ago }) : "", a.cached ? "server reuse" : ""].filter(Boolean).join(" · ") }));
    return box;
  }
  function renderFailure(r) {
    const neutral = NEUTRAL_FAILURES.has(r.failure.code);
    if (neutral) return h("p", { className: "neutral", text: failureText(r.failure.code, r.failure.retryAfter) });
    const copy = DECISION_COPY.UNKNOWN;
    const box = h("div", { className: "scanning" }, [
      h("div", { className: "verdict" }, [
        scoreRing("UNKNOWN", null),
        h("div", { className: "v-text" }, [h("p", { className: "v-label", text: copy.label }), h("p", { className: "v-reason", text: failureText(r.failure.code, r.failure.retryAfter) })])
      ])
    ]);
    if (r.failure.requestId) box.appendChild(h("p", { className: "muted tiny", text: `request_id ${r.failure.requestId}` }));
    return box;
  }
  function render(result) {
    stopTicker();
    lastResult = result;
    pageStatus.replaceChildren(result.kind === "assessment" ? renderAssessment(result.assessment, result.checkedAt) : renderFailure(result));
    const neutral = result.kind === "failure" && NEUTRAL_FAILURES.has(result.failure.code);
    recheck.hidden = !(paired && !neutral);
    reportCard.hidden = !paired || neutral;
    watchBtn.hidden = result.kind === "failure" && (result.failure.code === "OWN_SITE" || result.failure.code === "LOCAL_PAGE");
  }
  function renderChecking(host, since) {
    stopTicker();
    const elapsed = h("span", { className: "elapsed" });
    const tick = () => {
      elapsed.textContent = `${Math.max(0, Math.round((Date.now() - since) / 1e3))} s`;
    };
    tick();
    ticker = setInterval(tick, 1e3);
    pageStatus.replaceChildren(
      h("div", { className: "scanning", attrs: { role: "status" } }, [
        h("div", { className: "cov-top" }, [h("span", { text: fill(COPY.popup.checkingLive, { host }) }), elapsed]),
        h("div", { className: "scanbar", attrs: { "aria-hidden": "true" } }),
        h("p", { className: "muted", text: COPY.popup.checkingHint })
      ])
    );
  }
  function stopTicker() {
    if (ticker) clearInterval(ticker);
    ticker = null;
  }
  var knownUrl = null;
  async function tabUrl() {
    if (activeTab?.url) return activeTab.url;
    if (knownUrl) return knownUrl;
    if (activeTab?.id === void 0) return null;
    const r = await send({ type: "TAB_URL", tabId: activeTab.id });
    knownUrl = r.ok ? r.data : null;
    return knownUrl;
  }
  async function loadStatus(refresh = false) {
    const url = await tabUrl();
    if (!url || !/^https?:/i.test(url)) {
      pageHost.textContent = "";
      pageStatus.replaceChildren(h("p", { className: "neutral", text: COPY.popup.noPage }));
      watchBtn.hidden = true;
      reportCard.hidden = true;
      return;
    }
    const host = hostOf(toReportedUrl(url, DEMO_SITES_ORIGIN)) ?? "";
    pageHost.textContent = host;
    if (!refresh) {
      const peek = await send({ type: "PEEK_STATUS", url });
      if (peek.ok && peek.data.result) {
        render(peek.data.result);
        return;
      }
      renderChecking(host, peek.ok && peek.data.pendingSince ? peek.data.pendingSince : Date.now());
    } else {
      renderChecking(host, Date.now());
    }
    const reply = await send({ type: "GET_STATUS", url, refresh, tabId: activeTab?.id });
    render(reply.ok ? reply.data : { kind: "failure", failure: { code: "UNAVAILABLE" }, checkedAt: Date.now() });
  }
  function renderPairing(state, enabled) {
    paired = state.paired;
    pairCard.hidden = state.paired;
    if (!state.paired) byId("pair-heading").textContent = state.needsReconnect ? COPY.pair.reconnect : COPY.pair.heading;
    chip.dataset.state = !state.paired ? "none" : enabled ? "on" : "off";
    chip.textContent = !state.paired ? COPY.popup.notConnected : enabled ? COPY.popup.connected : COPY.popup.protectionOff;
    protect.disabled = !state.paired;
  }
  wirePairForm(byId("pair-form"), byId("pair-code"), byId("pair-error"), (state) => {
    renderPairing(state, protect.checked);
    void loadStatus(true);
  });
  protect.addEventListener("change", async () => {
    const s = await send({ type: "SET_SETTINGS", patch: { enabled: protect.checked } });
    const enabled = s.ok ? s.data.enabled : protect.checked;
    byId("protect-label").textContent = enabled ? COPY.popup.protectionOn : COPY.popup.protectionOff;
    const pairing = await send({ type: "GET_PAIRING" });
    if (pairing.ok) renderPairing(pairing.data, enabled);
    void loadStatus(true);
  });
  recheck.addEventListener("click", () => void loadStatus(true));
  byId("report-send").addEventListener("click", async () => {
    const url = await tabUrl();
    if (!url) return;
    const status = byId("report-status");
    const button = byId("report-send");
    button.disabled = true;
    status.textContent = COPY.pair.working;
    const a = lastResult?.kind === "assessment" ? lastResult.assessment : null;
    const reply = await send({
      type: "REPORT",
      url,
      justification: byId("report-text").value,
      observedPayee: a?.action?.payee ?? void 0,
      scanId: a?.scan_id ?? void 0
    });
    button.disabled = false;
    status.textContent = reply.ok ? COPY.reportSent : reply.error.code === "VALIDATION_FAILED" ? reply.error.message : COPY.reportQueued;
  });
  watchBtn.addEventListener("click", async () => {
    if (activeTab?.id === void 0) return;
    try {
      await chrome.scripting.executeScript({ target: { tabId: activeTab.id }, files: ["content.js"] });
      watchStatus.textContent = COPY.popup.watching;
    } catch {
      watchStatus.textContent = COPY.popup.noPage;
    }
  });
  void (async () => {
    const tabParam = Number(new URLSearchParams(location.search).get("tab"));
    activeTab = Number.isInteger(tabParam) && tabParam > 0 ? await chrome.tabs.get(tabParam).catch(() => void 0) : void 0;
    if (!activeTab) [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const [pairing, settings] = await Promise.all([send({ type: "GET_PAIRING" }), send({ type: "GET_SETTINGS" })]);
    const enabled = settings.ok ? settings.data.enabled : true;
    protect.checked = enabled;
    byId("protect-label").textContent = enabled ? COPY.popup.protectionOn : COPY.popup.protectionOff;
    if (pairing.ok) renderPairing(pairing.data, enabled);
    byId("api-line").textContent = "Server…";
    void send({ type: "API_STATUS" }).then((api) => {
      byId("api-dot").dataset.up = String(api.ok && api.data.reachable);
      byId("api-line").textContent = api.ok && api.data.reachable ? `Server ${api.data.version ?? ""}`.trim() : COPY.popup.apiDown;
    });
    await loadStatus();
  })();
})();
