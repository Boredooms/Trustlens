// src/shared/copy.ts
var DECISION_COPY = {
  BLOCK: {
    label: "Blocked",
    headline: "Blocked: {reason}",
    srText: "TrustLens decision: blocked.",
    icon: "shield-x",
    badge: "!"
  },
  WARN: {
    label: "Suspicious",
    headline: "Suspicious: {reason}",
    srText: "TrustLens decision: suspicious.",
    icon: "shield-alert",
    badge: "!"
  },
  ALLOW: {
    label: "No known threat",
    headline: "No known threat ({coverage}% checked)",
    srText: "TrustLens decision: no known threat in the checks that ran. This is not a guarantee.",
    icon: "shield-check",
    badge: ""
  },
  REVIEW: {
    label: "Needs review",
    headline: "Needs review: not enough evidence",
    srText: "TrustLens decision: needs review. Signals conflict or coverage is too low.",
    icon: "search",
    badge: "?"
  },
  UNKNOWN: {
    label: "Not verified",
    headline: "Not verified: {reason}",
    srText: "TrustLens could not verify this page. It was not checked.",
    icon: "shield-question",
    badge: "?"
  }
};
var FAILURE_COPY = {
  NOT_PAIRED: "TrustLens is not connected. Connect it in the popup to check pages.",
  RECONNECT: "Reconnect TrustLens to keep protecting you.",
  MISCONFIGURED: "This build needs an updated pairing.",
  RATE_LIMITED: "Too many checks right now — pausing for {n}s.",
  UNAVAILABLE: "TrustLens is unavailable — this page was not checked.",
  TIMEOUT: "TrustLens is unavailable — this page was not checked.",
  BAD_RESPONSE: "TrustLens is unavailable — this page was not checked.",
  CANNOT_CHECK_ADDRESS: "This address can't be checked.",
  CANNOT_CHECK_PAGE: "This page can't be checked.",
  PAUSED: "Protection paused — this page was not checked.",
  STALE: "Re-checking… the last result is more than 10 minutes old.",
  LOCAL_PAGE: "Local and private-network addresses are not checked.",
  OWN_SITE: "This is TrustLens itself, so it is not scanned."
};
var NEUTRAL_FAILURES = /* @__PURE__ */ new Set(["LOCAL_PAGE", "OWN_SITE", "PAUSED", "NOT_PAIRED"]);
function fill(template, values) {
  return template.replace(/\{(\w+)\}/g, (m, k) => k in values ? String(values[k]) : m);
}
function failureText(code, retryAfter) {
  return fill(FAILURE_COPY[code], { n: retryAfter ?? 60 });
}

// src/shared/config.ts
var API_BASE_URL = "https://trustlens-api-m65a.onrender.com".replace(/\/+$/, "");
var WEB_BASE_URL = "https://trustlens-web-three.vercel.app".replace(/\/+$/, "");
var DEMO_SITES_ORIGIN = "https://trustlens-demo-northstar.vercel.app";
var EXT_VERSION = "0.5.0";
var CONNECT_URL = `${WEB_BASE_URL}/app/developers?connect=extension`;
function isOwnPage(url) {
  try {
    const o = new URL(url).origin;
    return o === new URL(WEB_BASE_URL).origin || o === new URL(API_BASE_URL).origin;
  } catch {
    return false;
  }
}

// src/shared/demo-url.ts
var HOST_RE = /^(?=.{1,253}$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/i;
function parseOrigin(origin) {
  if (!origin) return null;
  try {
    const u = new URL(origin);
    return u.protocol === "http:" || u.protocol === "https:" ? u : null;
  } catch {
    return null;
  }
}
function toReportedUrl(raw, demoOrigin, base) {
  let u;
  try {
    u = base ? new URL(raw, base) : new URL(raw);
  } catch {
    return null;
  }
  if (u.protocol !== "http:" && u.protocol !== "https:") return null;
  u.hash = "";
  const demo = parseOrigin(demoOrigin);
  if (demo) {
    if (u.origin === demo.origin && u.pathname.startsWith("/site/")) {
      const rest = u.pathname.slice("/site/".length);
      const slash = rest.indexOf("/");
      const host = (slash === -1 ? rest : rest.slice(0, slash)).toLowerCase();
      const path = slash === -1 ? "/" : rest.slice(slash);
      if (HOST_RE.test(host)) return `https://${host}${path}${u.search}`;
      return u.toString();
    }
    const isExampleHost = u.hostname === "example" || u.hostname.endsWith(".example");
    if (isExampleHost && u.protocol === "http:" && u.port === demo.port) {
      return `https://${u.hostname}${u.pathname}${u.search}`;
    }
  }
  return u.toString();
}
function hostOf(url) {
  if (!url) return null;
  try {
    return new URL(url).hostname || null;
  } catch {
    return null;
  }
}
function isLocalHost(url) {
  const h = hostOf(url);
  if (!h) return true;
  const host = h.replace(/^\[|\]$/g, "").toLowerCase();
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host.endsWith(".internal") || host.endsWith(".lan")) {
    return true;
  }
  if (host === "::1" || host.startsWith("fe80:") || host.startsWith("fc") || host.startsWith("fd")) return host.includes(":");
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (!m) return false;
  const [a, b] = [Number(m[1]), Number(m[2])];
  return a === 127 || a === 10 || a === 0 || a === 192 && b === 168 || a === 172 && b >= 16 && b <= 31 || a === 169 && b === 254 || a === 100 && b >= 64 && b <= 127;
}

// src/shared/tokens.ts
var LIGHT = {
  background: "#f6f5f1",
  foreground: "#111111",
  surface: "#ffffff",
  "surface-secondary": "#ebe9e3",
  border: "#dad9d3",
  "border-strong": "#c4c2ba",
  muted: "#777777",
  "muted-strong": "#5c5c5c",
  primary: "#171717",
  "primary-foreground": "#ffffff",
  "primary-hover": "#2b2b2b",
  danger: "#c03939",
  "danger-surface": "#f7e9e9",
  warning: "#a87526",
  "warning-surface": "#f6efdf",
  success: "#397653",
  "success-surface": "#e8f0ea",
  unknown: "#626262",
  "unknown-surface": "#ececea",
  "focus-ring": "#171717",
  "focus-offset": "#f6f5f1"
};
var DECISION_TOKENS = {
  BLOCK: { text: "danger", surface: "danger-surface" },
  WARN: { text: "warning", surface: "warning-surface" },
  ALLOW: { text: "success", surface: "success-surface" },
  REVIEW: { text: "unknown", surface: "unknown-surface" },
  UNKNOWN: { text: "unknown", surface: "unknown-surface" }
};
function badgeColour(decision) {
  return LIGHT[DECISION_TOKENS[decision].text];
}

// src/shared/types.ts
var DECISIONS = ["BLOCK", "WARN", "ALLOW", "REVIEW", "UNKNOWN"];
var RISK_LEVELS = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "UNKNOWN"];
var DEFAULT_SETTINGS = { enabled: true };

// src/shared/assessment.ts
function normaliseDecision(value) {
  return typeof value === "string" && DECISIONS.includes(value) ? value : "UNKNOWN";
}
function normaliseRisk(value) {
  return typeof value === "string" && RISK_LEVELS.includes(value) ? value : "UNKNOWN";
}
function normaliseMatch(value) {
  return value === "exact" || value === "none" || value === "unverifiable" ? value : "unverifiable";
}
var str = (v) => typeof v === "string" ? v : null;
var strArray = (v) => Array.isArray(v) ? v.filter((x) => typeof x === "string") : [];
var obj = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : null;
function clampPercent(v) {
  if (typeof v !== "number" || !Number.isFinite(v)) return null;
  return Math.min(100, Math.max(0, Math.round(v)));
}
function parseAssessment(raw) {
  const o = obj(raw);
  if (!o) return null;
  const coverage = obj(o.coverage);
  const actionRaw = obj(o.action);
  let action = null;
  if (actionRaw) {
    const org = obj(actionRaw.claimed_organisation);
    action = {
      intent: str(actionRaw.intent) ?? "browse",
      claimed_organisation: org && typeof org.name === "string" ? { id: str(org.id) ?? "", name: org.name } : null,
      observed_destination: str(actionRaw.observed_destination),
      expected_destinations: strArray(actionRaw.expected_destinations),
      payee: str(actionRaw.payee),
      match: normaliseMatch(actionRaw.match)
    };
  }
  const findings = Array.isArray(o.findings) ? o.findings.flatMap((f) => {
    const fo = obj(f);
    if (!fo || typeof fo.code !== "string") return [];
    return [
      {
        id: str(fo.id) ?? void 0,
        code: fo.code,
        signal_group: str(fo.signal_group) ?? void 0,
        severity: str(fo.severity) ?? void 0,
        title: str(fo.title) ?? fo.code,
        detail: str(fo.detail),
        observed: obj(fo.observed),
        expected: obj(fo.expected)
      }
    ];
  }) : [];
  return {
    assessment_id: str(o.assessment_id),
    decision: normaliseDecision(o.decision),
    risk_level: normaliseRisk(o.risk_level),
    risk_score: typeof o.risk_score === "number" ? o.risk_score : null,
    coverage: {
      percent: clampPercent(coverage?.percent),
      collected: strArray(coverage?.collected),
      unavailable: strArray(coverage?.unavailable),
      skipped: strArray(coverage?.skipped)
    },
    reasons: strArray(o.reasons),
    identity_verified: o.identity_verified === true,
    action,
    findings,
    scan_id: str(o.scan_id),
    cached: o.cached === true,
    decided_at: str(o.decided_at)
  };
}

// src/shared/hash.ts
async function sha256Hex(input) {
  const bytes = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
}
var KEY_WINDOW_MS = 10 * 60 * 1e3;
async function assessIdempotencyKey(body, now = Date.now()) {
  const windowId = Math.floor(now / KEY_WINDOW_MS);
  const parts = [body.url, body.intent, body.payee ?? "", body.form_action ?? "", body.destination_host ?? "", windowId];
  return (await sha256Hex(parts.join("\n"))).slice(0, 64);
}

// src/background/api.ts
var BROWSE_TIMEOUT_MS = 45e3;
var ACTION_TIMEOUT_MS = 3e4;
var SERVER_RETRY_DELAY_MS = 2e3;
var TransportError = class extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
};
async function apiFetch(init, fetchImpl = fetch) {
  if (!init.path.startsWith("/")) throw new Error("apiFetch: path must be relative to the API base");
  const url = `${API_BASE_URL}${init.path}`;
  if (new URL(url).origin !== new URL(API_BASE_URL).origin) throw new Error("apiFetch: origin mismatch");
  const headers = { "X-Client": `ext/${EXT_VERSION}` };
  if (init.body) headers["Content-Type"] = "application/json";
  if (init.token) headers.Authorization = `Bearer ${init.token}`;
  if (init.idempotencyKey) headers["Idempotency-Key"] = init.idempotencyKey;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), init.timeoutMs);
  let res;
  try {
    res = await fetchImpl(url, {
      method: init.method,
      headers,
      body: init.body ? JSON.stringify(init.body) : void 0,
      credentials: "omit",
      cache: "no-store",
      signal: controller.signal
    });
  } catch {
    throw new TransportError(controller.signal.aborted ? "TIMEOUT" : "UNAVAILABLE");
  } finally {
    clearTimeout(timer);
  }
  let body = null;
  const text = await res.text().catch(() => "");
  if (text) {
    try {
      body = JSON.parse(text);
    } catch {
      body = null;
    }
  }
  return { status: res.status, body, headers: res.headers };
}
function errorCodeOf(body) {
  if (body && typeof body === "object" && "error" in body) {
    const e = body.error;
    if (e && typeof e.code === "string") return e.code;
  }
  return null;
}
function requestIdOf(res) {
  if (res.body && typeof res.body === "object" && "error" in res.body) {
    const e = res.body.error;
    if (e && typeof e.request_id === "string") return e.request_id;
  }
  return res.headers.get("x-request-id");
}
function retryAfterSeconds(headers) {
  const v = headers.get("retry-after");
  if (!v) return null;
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? n : null;
}
var ADDRESS_CODES = /* @__PURE__ */ new Set([
  "TARGET_NOT_ALLOWED",
  "UNSUPPORTED_SCHEME",
  "UNSUPPORTED_PORT",
  "URL_HAS_CREDENTIALS",
  "DNS_RESOLUTION_FAILED"
]);
function failureFromResponse(res) {
  const code = errorCodeOf(res.body);
  const requestId = requestIdOf(res);
  let f;
  if (res.status === 401) f = "RECONNECT";
  else if (res.status === 403) f = "MISCONFIGURED";
  else if (res.status === 429) return { code: "RATE_LIMITED", retryAfter: retryAfterSeconds(res.headers), requestId };
  else if (res.status === 422 && code && ADDRESS_CODES.has(code)) f = "CANNOT_CHECK_ADDRESS";
  else if (res.status === 422 || res.status === 400 || res.status === 404) f = "CANNOT_CHECK_PAGE";
  else f = "UNAVAILABLE";
  return { code: f, requestId };
}
async function assess(body, token, fetchImpl = fetch, sleep = (ms) => new Promise((r) => setTimeout(r, ms))) {
  const clean = { url: body.url, intent: body.intent };
  if (body.form_action) clean.form_action = body.form_action;
  if (body.payee) clean.payee = body.payee;
  if (body.destination_host) clean.destination_host = body.destination_host;
  const idempotencyKey = await assessIdempotencyKey(body);
  const timeoutMs = body.intent === "browse" ? BROWSE_TIMEOUT_MS : ACTION_TIMEOUT_MS;
  for (let attempt = 0; attempt < 2; attempt++) {
    let res;
    try {
      res = await apiFetch({ method: "POST", path: "/api/v1/assess", body: clean, token, idempotencyKey, timeoutMs }, fetchImpl);
    } catch (err) {
      const code = err instanceof TransportError ? err.code : "UNAVAILABLE";
      return { kind: "failure", failure: { code }, checkedAt: Date.now() };
    }
    if (res.status >= 200 && res.status < 300) {
      const assessment = parseAssessment(res.body);
      if (!assessment) {
        return { kind: "failure", failure: { code: "BAD_RESPONSE", requestId: requestIdOf(res) }, checkedAt: Date.now() };
      }
      return { kind: "assessment", assessment, checkedAt: Date.now() };
    }
    if (res.status >= 500 && attempt === 0) {
      await sleep(SERVER_RETRY_DELAY_MS);
      continue;
    }
    return { kind: "failure", failure: failureFromResponse(res), checkedAt: Date.now() };
  }
  return { kind: "failure", failure: { code: "UNAVAILABLE" }, checkedAt: Date.now() };
}

// src/shared/cache.ts
var VERDICT_TTL_MS = 10 * 60 * 1e3;
function readCache(entry, now = Date.now()) {
  if (!entry || typeof entry !== "object") return { state: "miss" };
  const e = entry;
  if (typeof e.cachedAt !== "number" || !Number.isFinite(e.cachedAt) || !e.result || typeof e.result !== "object") {
    return { state: "miss" };
  }
  const ageMs = now - e.cachedAt;
  if (ageMs < 0 || ageMs > VERDICT_TTL_MS) return { state: "stale", ageMs };
  if (e.result.kind !== "assessment") return { state: "miss" };
  return { state: "fresh", result: e.result, ageMs };
}
function isCacheable(result) {
  return result.kind === "assessment";
}

// src/background/storage.ts
var SCHEMA_VERSION = 1;
var MAX_VERDICTS = 200;
async function migrate() {
  const { schemaVersion } = await chrome.storage.local.get("schemaVersion");
  if (schemaVersion === SCHEMA_VERSION) return;
  if (typeof schemaVersion === "number" && schemaVersion > SCHEMA_VERSION) {
    await chrome.storage.local.clear();
  }
  await chrome.storage.local.set({ schemaVersion: SCHEMA_VERSION });
}
async function getToken() {
  const { device_token } = await chrome.storage.local.get("device_token");
  return typeof device_token === "string" && device_token.startsWith("tl_ext_") ? device_token : null;
}
async function savePairing(p) {
  await chrome.storage.local.set({
    device_token: p.device_token,
    device_id: p.device_id,
    device_expires_at: p.expires_at,
    needs_reconnect: false,
    last_me_check: Date.now()
  });
}
async function clearToken(needsReconnect) {
  await chrome.storage.local.remove(["device_token", "device_id", "device_expires_at", "last_me_check"]);
  await chrome.storage.local.set({ needs_reconnect: needsReconnect });
  await clearVerdicts();
}
async function getPairing() {
  const s = await chrome.storage.local.get(["device_token", "device_id", "device_expires_at", "needs_reconnect"]);
  return {
    paired: typeof s.device_token === "string" && s.device_token.startsWith("tl_ext_"),
    needsReconnect: s.needs_reconnect === true,
    deviceId: typeof s.device_id === "string" ? s.device_id : null,
    expiresAt: typeof s.device_expires_at === "string" ? s.device_expires_at : null
  };
}
async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  const s = settings && typeof settings === "object" ? settings : {};
  return { enabled: typeof s.enabled === "boolean" ? s.enabled : DEFAULT_SETTINGS.enabled };
}
async function setSettings(patch) {
  const next = { ...await getSettings() };
  if (typeof patch.enabled === "boolean") next.enabled = patch.enabled;
  await chrome.storage.local.set({ settings: next });
  return next;
}
async function verdictKey(url) {
  return `verdict:${await sha256Hex(url)}`;
}
async function readVerdict(url, now = Date.now()) {
  const key = await verdictKey(url);
  const got = await chrome.storage.session.get(key);
  return readCache(got[key], now);
}
async function writeVerdict(url, result) {
  if (!isCacheable(result)) return;
  const entry = { result, cachedAt: result.checkedAt };
  try {
    await chrome.storage.session.set({ [await verdictKey(url)]: entry });
    await evictVerdicts();
  } catch {
    await evictVerdicts(0).catch(() => void 0);
  }
}
async function evictVerdicts(keep = MAX_VERDICTS) {
  const all = await chrome.storage.session.get(null);
  const entries = Object.entries(all).filter(([k]) => k.startsWith("verdict:")).map(([k, v]) => [k, v?.cachedAt ?? 0]).sort((a, b) => b[1] - a[1]);
  const drop = entries.slice(keep).map(([k]) => k);
  if (drop.length) await chrome.storage.session.remove(drop);
}
async function clearVerdicts() {
  const all = await chrome.storage.session.get(null);
  const keys = Object.keys(all).filter((k) => k.startsWith("verdict:"));
  if (keys.length) await chrome.storage.session.remove(keys);
}
async function getRateLimitedUntil() {
  const { rate_limited_until } = await chrome.storage.session.get("rate_limited_until");
  return typeof rate_limited_until === "number" ? rate_limited_until : 0;
}
async function setRateLimitedFor(seconds) {
  const s = typeof seconds === "number" && seconds > 0 ? seconds : 60;
  await chrome.storage.session.set({ rate_limited_until: Date.now() + s * 1e3 });
}
async function dismissWarn(host) {
  await chrome.storage.session.set({ [`warn_dismissed:${host}`]: true });
}
async function isWarnDismissed(host) {
  const k = `warn_dismissed:${host}`;
  const got = await chrome.storage.session.get(k);
  return got[k] === true;
}
async function flagHost(host, decision, now = Date.now()) {
  await chrome.storage.session.set({ [`flag:${host}`]: { decision, at: now } });
}
async function flaggedHosts(now = Date.now()) {
  const all = await chrome.storage.session.get(null);
  const out = {};
  for (const [k, v] of Object.entries(all)) {
    if (!k.startsWith("flag:")) continue;
    const e = v;
    if (!e || typeof e.at !== "number" || now - e.at < 0 || now - e.at > VERDICT_TTL_MS) continue;
    if (e.decision === "BLOCK" || e.decision === "WARN") out[k.slice(5)] = e.decision;
  }
  return out;
}
async function setPageOverride(host, decision) {
  const current = await getPageOverride(host);
  if (current === "BLOCK") return;
  await chrome.storage.session.set({ [`page_override:${host}`]: decision });
}
async function getPageOverride(host) {
  const k = `page_override:${host}`;
  const got = await chrome.storage.session.get(k);
  return got[k] === "BLOCK" || got[k] === "WARN" ? got[k] : null;
}
async function recordOverride(taken) {
  const { overrides } = await chrome.storage.local.get("overrides");
  const o = overrides && typeof overrides === "object" ? overrides : {};
  await chrome.storage.local.set({
    overrides: { shown: (o.shown ?? 0) + 1, taken: (o.taken ?? 0) + (taken ? 1 : 0) }
  });
}
async function clearAll() {
  await chrome.storage.local.clear();
  await chrome.storage.session.clear();
  await chrome.storage.local.set({ schemaVersion: SCHEMA_VERSION });
}

// src/background/service-worker.ts
var ME_CHECK_INTERVAL_MS = 24 * 60 * 60 * 1e3;
var MAX_PAYEE_LEN = 128;
var PAIRING_TIMEOUT_MS = 1e4;
var fail = (code, extra = {}) => ({
  kind: "failure",
  failure: { code, ...extra },
  checkedAt: Date.now()
});
function decisionOf(r) {
  return r.kind === "assessment" ? r.assessment.decision : "UNKNOWN";
}
async function setBadge(tabId, r) {
  if (tabId === void 0) return;
  const d = decisionOf(r);
  try {
    if (r.kind === "failure" && NEUTRAL_FAILURES.has(r.failure.code)) {
      await chrome.action.setBadgeText({ tabId, text: "" });
      await chrome.action.setTitle({ tabId, title: `TrustLens — ${failureText(r.failure.code)}` });
      return;
    }
    await chrome.action.setBadgeText({ tabId, text: DECISION_COPY[d].badge });
    if (DECISION_COPY[d].badge) await chrome.action.setBadgeBackgroundColor({ tabId, color: badgeColour(d) });
    await chrome.action.setTitle({ tabId, title: `TrustLens — ${DECISION_COPY[d].label}` });
  } catch {
  }
}
async function afterResult(r) {
  if (r.kind === "failure") {
    if (r.failure.code === "RECONNECT") await clearToken(true);
    if (r.failure.code === "RATE_LIMITED") await setRateLimitedFor(r.failure.retryAfter);
  }
  return r;
}
function localState(rawUrl) {
  const url = toReportedUrl(rawUrl, DEMO_SITES_ORIGIN);
  if (!url) return { url: null, result: fail("CANNOT_CHECK_PAGE") };
  if (isOwnPage(rawUrl)) return { url, result: fail("OWN_SITE") };
  if (isLocalHost(url)) return { url, result: fail("LOCAL_PAGE") };
  return { url, result: null };
}
var inflight = /* @__PURE__ */ new Map();
async function setPendingBadge(tabId) {
  if (tabId === void 0) return;
  try {
    await chrome.action.setBadgeText({ tabId, text: "…" });
    await chrome.action.setBadgeBackgroundColor({ tabId, color: badgeColour("UNKNOWN") });
    await chrome.action.setTitle({ tabId, title: "TrustLens — checking this page" });
  } catch {
  }
}
async function browseCheck(rawUrl, forceRefresh = false, tabId) {
  const settings = await getSettings();
  if (!settings.enabled) return fail("PAUSED");
  const local = localState(rawUrl);
  if (local.result || !local.url) return local.result ?? fail("CANNOT_CHECK_PAGE");
  const url = local.url;
  const token = await getToken();
  if (!token) return fail((await getPairing()).needsReconnect ? "RECONNECT" : "NOT_PAIRED");
  if (!forceRefresh) {
    const cached = await readVerdict(url);
    if (cached.state === "fresh") return cached.result;
    const running = inflight.get(url);
    if (running) return running.promise;
  }
  const until = await getRateLimitedUntil();
  if (until > Date.now()) return fail("RATE_LIMITED", { retryAfter: Math.ceil((until - Date.now()) / 1e3) });
  await setPendingBadge(tabId);
  const promise = (async () => {
    const result = await afterResult(await assess({ url, intent: "browse" }, token));
    await writeVerdict(url, result);
    await noteFlag(url, result);
    return result;
  })();
  inflight.set(url, { promise, startedAt: Date.now() });
  try {
    return await promise;
  } finally {
    inflight.delete(url);
  }
}
async function peekStatus(rawUrl) {
  const settings = await getSettings();
  if (!settings.enabled) return { result: fail("PAUSED"), pendingSince: null };
  const local = localState(rawUrl);
  if (local.result || !local.url) return { result: local.result, pendingSince: null };
  const cached = await readVerdict(local.url);
  return {
    result: cached.state === "fresh" ? cached.result : null,
    pendingSince: inflight.get(local.url)?.startedAt ?? null
  };
}
function senderOrigin(sender) {
  try {
    return sender.url ? new URL(sender.url).origin : null;
  } catch {
    return null;
  }
}
function hostOfSender(sender) {
  return sender.url ? hostOf(toReportedUrl(sender.url, DEMO_SITES_ORIGIN)) : null;
}
async function noteFlag(url, result) {
  if (result.kind !== "assessment") return;
  const d = result.assessment.decision;
  const host = hostOf(url);
  if (host && (d === "BLOCK" || d === "WARN")) await flagHost(host, d);
}
function fromDashboard(sender) {
  return typeof sender.tab?.id === "number" && sender.frameId === 0 && senderOrigin(sender) === new URL(WEB_BASE_URL).origin;
}
async function actionCheck(msg) {
  const settings = await getSettings();
  if (!settings.enabled) return fail("PAUSED");
  const local = localState(msg.url);
  if (local.result || !local.url) return local.result ?? fail("CANNOT_CHECK_PAGE");
  const url = local.url;
  const token = await getToken();
  if (!token) return fail((await getPairing()).needsReconnect ? "RECONNECT" : "NOT_PAIRED");
  const body = { url, intent: msg.intent };
  const formAction = msg.formAction ? toReportedUrl(msg.formAction, DEMO_SITES_ORIGIN) : null;
  if (formAction) {
    body.form_action = formAction;
    const host = hostOf(formAction);
    if (host) body.destination_host = host;
  } else if (msg.destinationHost && /^[a-z0-9.-]{1,253}$/i.test(msg.destinationHost)) {
    body.destination_host = msg.destinationHost.toLowerCase();
  }
  if (msg.intent === "payment" && typeof msg.payee === "string") {
    const payee = msg.payee.trim().slice(0, MAX_PAYEE_LEN);
    if (payee) body.payee = payee;
  }
  const actionKey = ["action", url, body.intent, body.payee ?? "", body.form_action ?? "", body.destination_host ?? ""].join("\n");
  const cached = await readVerdict(actionKey);
  if (cached.state === "fresh") return cached.result;
  const running = inflight.get(actionKey);
  if (running) return running.promise;
  const promise = (async () => {
    const result = await afterResult(await assess(body, token));
    await writeVerdict(actionKey, result);
    await noteFlag(url, result);
    return result;
  })();
  inflight.set(actionKey, { promise, startedAt: Date.now() });
  try {
    return await promise;
  } finally {
    inflight.delete(actionKey);
  }
}
async function pair(code, deviceName) {
  const compact = code.trim().toUpperCase().replace(/[\s-]/g, "");
  if (!/^[A-Z0-9]{8}$/.test(compact)) {
    return { ok: false, error: { code: "INVALID_CODE", message: "Enter the 8-character code." } };
  }
  const cleaned = `${compact.slice(0, 4)}-${compact.slice(4)}`;
  try {
    const res = await apiFetch({
      method: "POST",
      path: "/api/v1/auth/extension/exchange",
      body: { code: cleaned, device_name: deviceName.slice(0, 100) || "Chrome" },
      timeoutMs: PAIRING_TIMEOUT_MS
    });
    const b = res.body;
    if (res.status >= 200 && res.status < 300 && b && typeof b.device_token === "string" && b.device_token.startsWith("tl_ext_")) {
      await savePairing({
        device_token: b.device_token,
        device_id: typeof b.device_id === "string" ? b.device_id : null,
        expires_at: typeof b.expires_at === "string" ? b.expires_at : null
      });
      await clearVerdicts();
      return { ok: true, data: await getPairing() };
    }
    if (res.status === 401 || res.status === 410 || res.status === 422) {
      return { ok: false, error: { code: "INVALID_CODE", message: errorCodeOf(res.body) ?? `HTTP ${res.status}` } };
    }
    return { ok: false, error: { code: "PAIR_FAILED", message: errorCodeOf(res.body) ?? `HTTP ${res.status}` } };
  } catch (err) {
    return { ok: false, error: { code: "PAIR_FAILED", message: err instanceof TransportError ? err.code : "UNAVAILABLE" } };
  }
}
async function maybeCheckMe() {
  const token = await getToken();
  if (!token) return;
  const { last_me_check } = await chrome.storage.local.get("last_me_check");
  if (typeof last_me_check === "number" && Date.now() - last_me_check < ME_CHECK_INTERVAL_MS) return;
  try {
    const res = await apiFetch({ method: "GET", path: "/api/v1/auth/me", token, timeoutMs: 8e3 });
    if (res.status === 401) await clearToken(true);
    else if (res.status >= 200 && res.status < 300) await chrome.storage.local.set({ last_me_check: Date.now() });
  } catch {
  }
}
async function report(msg) {
  const token = await getToken();
  if (!token) return { ok: false, error: { code: "NOT_PAIRED", message: "Not connected" } };
  const url = toReportedUrl(msg.url, DEMO_SITES_ORIGIN);
  if (!url) return { ok: false, error: { code: "CANNOT_CHECK_PAGE", message: "This page can't be reported." } };
  const body = { url };
  if (msg.intent) body.intent = msg.intent;
  if (msg.observedPayee) body.observed_payee = msg.observedPayee.slice(0, MAX_PAYEE_LEN);
  if (msg.scanId) body.scan_id = msg.scanId;
  const j = msg.justification?.trim();
  if (j) {
    if (j.length < 10 || j.length > 500) {
      return { ok: false, error: { code: "VALIDATION_FAILED", message: "Use 10–500 characters, or leave it empty." } };
    }
    body.justification = j;
  }
  try {
    const res = await apiFetch({
      method: "POST",
      path: "/api/v1/reports",
      body,
      token,
      idempotencyKey: `ext-report-${crypto.randomUUID()}`,
      timeoutMs: 1e4
    });
    if (res.status === 401) {
      await clearToken(true);
      return { ok: false, error: { code: "RECONNECT", message: "Reconnect" } };
    }
    const code = errorCodeOf(res.body);
    if (res.status === 409 && code === "REPORT_DUPLICATE") return { ok: true, data: { id: null, status: "pending" } };
    if (res.status >= 200 && res.status < 300) {
      const b = res.body;
      return {
        ok: true,
        data: { id: typeof b?.id === "string" ? b.id : null, status: typeof b?.status === "string" ? b.status : null }
      };
    }
    return { ok: false, error: { code: code ?? `HTTP_${res.status}`, message: `HTTP ${res.status}` } };
  } catch (err) {
    return { ok: false, error: { code: err instanceof TransportError ? err.code : "UNAVAILABLE", message: "Unreachable" } };
  }
}
async function apiStatus() {
  try {
    const res = await apiFetch({ method: "GET", path: "/health", timeoutMs: 5e3 });
    const b = res.body;
    return { reachable: res.status === 200, version: typeof b?.version === "string" ? b.version : null };
  } catch {
    return { reachable: false, version: null };
  }
}
var EXTENSION_PAGE_ONLY = /* @__PURE__ */ new Set([
  "GET_STATUS",
  "PEEK_STATUS",
  "TAB_URL",
  "PAIR",
  "GET_PAIRING",
  "UNPAIR",
  "CLEAR_DATA",
  "API_STATUS",
  "SET_SETTINGS"
]);
var DASHBOARD_ONLY = /* @__PURE__ */ new Set(["BRIDGE_HELLO", "PAIR_FROM_DASHBOARD"]);
var CONTENT_ALLOWED = /* @__PURE__ */ new Set([
  "PAGE_READY",
  "ACTION_INTENT",
  "REPORT",
  "GET_SETTINGS",
  "RECORD_OVERRIDE",
  "DISMISS_WARN",
  "IS_WARN_DISMISSED",
  "FLAGGED_HOSTS",
  "SET_PAGE_OVERRIDE",
  "GET_PAGE_OVERRIDE"
]);
function isMsg(m) {
  return Boolean(m) && typeof m === "object" && typeof m.type === "string";
}
function isExtensionPage(sender) {
  return typeof sender.url === "string" && sender.url.startsWith(chrome.runtime.getURL(""));
}
async function handle(msg, sender) {
  if (sender.id !== chrome.runtime.id) return { ok: false, error: { code: "FORBIDDEN", message: "Unknown sender" } };
  const fromPage = isExtensionPage(sender);
  const fromTab = !fromPage && typeof sender.tab?.id === "number";
  if (EXTENSION_PAGE_ONLY.has(msg.type) && !fromPage) {
    return { ok: false, error: { code: "FORBIDDEN", message: "Not allowed from a web page" } };
  }
  if (DASHBOARD_ONLY.has(msg.type)) {
    if (!fromDashboard(sender)) return { ok: false, error: { code: "FORBIDDEN", message: "Only the TrustLens dashboard may do this" } };
    if (msg.type === "BRIDGE_HELLO") return { ok: true, data: { version: EXT_VERSION, paired: (await getPairing()).paired } };
    if (msg.type === "PAIR_FROM_DASHBOARD" && typeof msg.code === "string") {
      return pair(msg.code, typeof msg.deviceName === "string" ? msg.deviceName : "Chrome");
    }
    return { ok: false, error: { code: "BAD_MESSAGE", message: "Malformed message" } };
  }
  if (!EXTENSION_PAGE_ONLY.has(msg.type) && !CONTENT_ALLOWED.has(msg.type)) {
    return { ok: false, error: { code: "UNKNOWN_MESSAGE", message: msg.type } };
  }
  if (CONTENT_ALLOWED.has(msg.type) && !fromTab && !fromPage) {
    return { ok: false, error: { code: "FORBIDDEN", message: "Missing tab" } };
  }
  const str2 = (v) => typeof v === "string";
  switch (msg.type) {
    case "PAGE_READY": {
      if (!str2(msg.url)) break;
      void maybeCheckMe();
      if (typeof sender.tab?.id === "number") void chrome.storage.session.set({ [`tab_url:${sender.tab.id}`]: msg.url });
      const r = await browseCheck(msg.url, false, sender.tab?.id);
      await setBadge(sender.tab?.id, r);
      return { ok: true, data: r };
    }
    case "GET_STATUS": {
      if (!str2(msg.url)) break;
      const tabId = typeof msg.tabId === "number" ? msg.tabId : void 0;
      const r = await browseCheck(msg.url, msg.refresh === true, tabId);
      await setBadge(tabId, r);
      return { ok: true, data: r };
    }
    case "PEEK_STATUS":
      if (!str2(msg.url)) break;
      return { ok: true, data: await peekStatus(msg.url) };
    case "TAB_URL": {
      if (typeof msg.tabId !== "number") break;
      const key = `tab_url:${msg.tabId}`;
      const got = await chrome.storage.session.get(key);
      return { ok: true, data: typeof got[key] === "string" ? got[key] : null };
    }
    case "ACTION_INTENT": {
      if (!str2(msg.url) || msg.intent !== "login" && msg.intent !== "payment") break;
      const r = await actionCheck({
        type: "ACTION_INTENT",
        url: msg.url,
        intent: msg.intent,
        formAction: str2(msg.formAction) ? msg.formAction : void 0,
        payee: str2(msg.payee) ? msg.payee : void 0,
        destinationHost: str2(msg.destinationHost) ? msg.destinationHost : void 0
      });
      await setBadge(sender.tab?.id, r);
      return { ok: true, data: r };
    }
    case "REPORT":
      if (!str2(msg.url)) break;
      return report(msg);
    case "PAIR":
      if (!str2(msg.code)) break;
      return pair(msg.code, str2(msg.deviceName) ? msg.deviceName : "Chrome");
    case "GET_PAIRING":
      void maybeCheckMe();
      return { ok: true, data: await getPairing() };
    case "UNPAIR":
      await clearToken(false);
      return { ok: true, data: await getPairing() };
    case "CLEAR_DATA":
      await clearAll();
      return { ok: true, data: null };
    case "API_STATUS":
      return { ok: true, data: await apiStatus() };
    case "GET_SETTINGS":
      return { ok: true, data: await getSettings() };
    case "SET_SETTINGS":
      return { ok: true, data: await setSettings(msg.patch ?? {}) };
    case "RECORD_OVERRIDE":
      await recordOverride(msg.taken === true);
      return { ok: true, data: null };
    case "DISMISS_WARN":
      if (!str2(msg.host)) break;
      await dismissWarn(msg.host);
      return { ok: true, data: null };
    case "IS_WARN_DISMISSED":
      if (!str2(msg.host)) break;
      return { ok: true, data: await isWarnDismissed(msg.host) };
    case "FLAGGED_HOSTS":
      return { ok: true, data: await flaggedHosts() };
    case "SET_PAGE_OVERRIDE": {
      const own = hostOfSender(sender);
      if (!str2(msg.host) || msg.decision !== "BLOCK" && msg.decision !== "WARN" || own !== msg.host) break;
      await setPageOverride(msg.host, msg.decision);
      return { ok: true, data: null };
    }
    case "GET_PAGE_OVERRIDE":
      if (!str2(msg.host)) break;
      return { ok: true, data: await getPageOverride(msg.host) };
  }
  return { ok: false, error: { code: "BAD_MESSAGE", message: "Malformed message" } };
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!isMsg(msg)) {
    sendResponse({ ok: false, error: { code: "BAD_MESSAGE", message: "Malformed message" } });
    return false;
  }
  handle(msg, sender).then(sendResponse).catch(
    (err) => sendResponse({ ok: false, error: { code: "INTERNAL", message: err instanceof Error ? err.message : "error" } })
  );
  return true;
});
chrome.runtime.onInstalled.addListener(() => {
  void migrate();
});
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status === "loading") void chrome.action.setBadgeText({ tabId, text: "" }).catch(() => void 0);
});
chrome.tabs.onRemoved.addListener((tabId) => {
  void chrome.storage.session.remove(`tab_url:${tabId}`).catch(() => void 0);
});
